# control_comm.py

from servo_module import FixedMode, RotateMode  # 서보 모드 클래스 임포트
# servo_controller, fan_controller는 객체로 전달받으므로 여기서는 import 불필요

class ControlComm:
    def __init__(self, servo_controller, fan_controller):
        self.servo_controller = servo_controller
        self.fan_controller = fan_controller
        self.state = {
            "servo_mode": None,
            "servo_value": 0,
            "fan_speed": 0,
            "fan_mode": 0,
            "automation": False,
        }

    def set_servo(self, mode, value):
        self.state["servo_mode"] = mode
        self.state["servo_value"] = value
        if mode == "fixed":
            self.servo_controller.move_to(FixedMode(value))
        elif mode == "rotate":
            self.servo_controller.move_to(RotateMode(value))
        self._save_config("servo", mode, value)

    def set_fan(self, speed=None, mode=None):
        if speed is not None:
            self.state["fan_speed"] = speed
            self.fan_controller.set_speed(speed)
            self._save_config("fan", "speed", speed)
        elif mode is not None:
            self.state["fan_mode"] = mode
            self.fan_controller.set_mode(mode)
            self._save_config("fan", "mode", mode)

#자동화 ON/OFF
    def toggle_automation(self, enabled):
        self.state["automation"] = enabled
        print(f"✅ 자동화 모드: {'활성화됨' if enabled else '비활성화됨'}")
        self._save_config("system", "automation", int(enabled))

#저장 동작 시뮬
    def _save_config(self, category, kind, value):
        print(f"[📁 Conf Save] {category.upper()} - {kind}: {value}")
