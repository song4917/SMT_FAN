# test_control.py

from servo_module import Servo, ServoController, FixedMode, RotateMode
from fan_module import Fan, FanController
from control_comm import ControlComm

def console_ui(comm: ControlComm, servo_controller, fan_controller):
    print("🔧 UI 제어 시뮬레이터 시작 (예: FIX 90, ROTATE 60, FAN 70, MODE 1, AUTO ON, EXIT)")

    while True:
        cmd = input("UI 입력 > ").strip().upper()
        if cmd == "EXIT":
            break

        try:
            if cmd.startswith("FIX "):
                comm.set_servo("fixed", int(cmd[4:]))
            elif cmd.startswith("ROTATE "):
                comm.set_servo("rotate", int(cmd[7:]))
            elif cmd.startswith("FAN "):
                comm.set_fan(speed=int(cmd[4:]))
            elif cmd.startswith("MODE "):
                comm.set_fan(mode=int(cmd[5:]))
            elif cmd.startswith("AUTO "):
                comm.toggle_automation(cmd[5:] == "ON")
            else:
                print("❌ 알 수 없는 명령입니다.")
        except Exception as e:
            print(f"⚠️ 오류 발생: {e}")

    servo_controller.stop()
    fan_controller.stop()

def parse_and_execute(command_str, comm: ControlComm):
    command_str = command_str.strip().upper()

    if command_str.startswith("R"):
        try:
            value = int(command_str[1:])
            comm.set_servo("rotate", value)
        except ValueError:
            print("❌ 잘못된 RotateMode 입력입니다. 예: R50")

    elif command_str.startswith("F"):
        try:
            value = int(command_str[1:])
            comm.set_servo("fixed", value)
        except ValueError:
            print("❌ 잘못된 FixedMode 입력입니다. 예: F90")

    elif command_str.startswith("S"):
        try:
            value = int(command_str[1:])
            comm.set_fan(speed=value)
        except ValueError:
            print("❌ 잘못된 팬 속도 입력입니다. 예: S70")

    elif command_str.startswith("M"):
        try:
            value = int(command_str[1:])
            comm.set_fan(mode=value)
        except ValueError:
            print("❌ 잘못된 팬 모드 입력입니다. 예: M0, M1, M2")

    elif command_str.startswith("A"):
        if command_str[1:] == "1":
            comm.toggle_automation(True)
        elif command_str[1:] == "0":
            comm.toggle_automation(False)
        else:
            print("❌ 잘못된 자동화 명령입니다. 예: A1 (ON), A0 (OFF)")

    else:
        print("❌ 명령을 인식할 수 없습니다. 예: R50, F90, S70, M1, A1, UI")

def main():
    servo = Servo("Circulator Servo")
    servo_controller = ServoController(servo)

    fan = Fan("Circulator Fan")
    fan_controller = FanController(fan)

    comm = ControlComm(servo_controller, fan_controller)

    print("🧪 명령을 입력하세요 (예: R50, F90, S70, M1, A1, UI), 종료하려면 'exit' 입력")

    try:
        while True:
            user_input = input("입력 > ").strip().lower()
            if user_input == "exit":
                servo_controller.stop()
                fan_controller.stop()
                break
            elif user_input == "ui":
                console_ui(comm, servo_controller, fan_controller)
            else:
                parse_and_execute(user_input, comm)
    except KeyboardInterrupt:
        servo_controller.stop()
        fan_controller.stop()
        print("\n종료되었습니다.")

if __name__ == "__main__":
    main()
