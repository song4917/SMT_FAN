import threading
import time
from abc import ABC, abstractmethod
from motion_utils import gradual_move

# --- Command Base ---
class Command(ABC):
    @abstractmethod
    def execute(self, device, stop_event):
        pass

# --- Device Base ---
class Device:
    def __init__(self, name):
        self.name = name

# --- Servo Device ---
class Servo(Device):
    def __init__(self, name):
        super().__init__(name)
        self.angle = 0

    def set_angle_gradually(self, target_angle, step=1, delay=0.01, stop_event=None):
        print(f"[{self.name}] Moving from {self.angle}° to {target_angle}°")

        def update_callback(angle):
            self.angle = angle
            print(f" → Angle: {self.angle}°")

        gradual_move(
            current_angle=self.angle,
            target_angle=target_angle,
            step=step,
            delay=delay,
            stop_event=stop_event,
            update_callback=update_callback
        )

    def get_angle(self):
        return self.angle

# --- Fan Device ---
class Fan(Device):
    def __init__(self, name):
        super().__init__(name)
        self.speed = 0

    def set_speed_gradually(self, target_speed, step=1, delay=0.01, stop_event=None):
        print(f"[{self.name}] Changing speed from {self.speed}% to {target_speed}%")

        def update_callback(speed):
            self.speed = speed
            print(f" → Speed: {self.speed}%")

        gradual_move(
            current_angle=self.speed,
            target_angle=target_speed,
            step=step,
            delay=delay,
            stop_event=stop_event,
            update_callback=update_callback
        )

    def get_speed(self):
        return self.speed

# --- Servo Modes ---
class FixedMode(Command):
    def __init__(self, angle):
        self.angle = angle

    def execute(self, servo: Servo, stop_event):
        servo.set_angle_gradually(self.angle, stop_event=stop_event)

class RotateMode(Command):
    def __init__(self, delta_angle):
        self.delta_angle = delta_angle

    def execute(self, servo: Servo, stop_event):
        center = servo.get_angle()
        min_angle = center - self.delta_angle // 2
        max_angle = center + self.delta_angle // 2
        print(f"[{servo.name}] Oscillating between {min_angle}° and {max_angle}°")

        while not stop_event.is_set():
            for angle in range(min_angle, max_angle + 1):
                if stop_event.is_set():
                    return
                servo.angle = angle
                print(f" → Angle: {servo.angle}°")
                time.sleep(0.01)
            for angle in range(max_angle, min_angle - 1, -1):
                if stop_event.is_set():
                    return
                servo.angle = angle
                print(f" → Angle: {servo.angle}°")
                time.sleep(0.01)

# --- Fan Modes ---
class FixedSpeed(Command):
    def __init__(self, speed):
        self.speed = speed

    def execute(self, fan: Fan, stop_event):
        fan.set_speed_gradually(self.speed, stop_event=stop_event)

class OscillateSpeed(Command):
    def __init__(self, delta_speed):
        self.delta_speed = delta_speed

    def execute(self, fan: Fan, stop_event):
        center = fan.get_speed()
        min_speed = max(0, center - self.delta_speed // 2)
        max_speed = min(100, center + self.delta_speed // 2)
        print(f"[{fan.name}] Oscillating between {min_speed}% and {max_speed}%")

        while not stop_event.is_set():
            for speed in range(min_speed, max_speed + 1):
                if stop_event.is_set():
                    return
                fan.speed = speed
                print(f" → Speed: {fan.speed}%")
                time.sleep(0.01)
            for speed in range(max_speed, min_speed - 1, -1):
                if stop_event.is_set():
                    return
                fan.speed = speed
                print(f" → Speed: {fan.speed}%")
                time.sleep(0.01)

# --- Controller (공통 구조) ---
class BaseController:
    def __init__(self, device: Device):
        self.device = device
        self.thread = None
        self.stop_event = threading.Event()

    def move_to(self, mode: Command):
        if self.thread and self.thread.is_alive():
            print(f"[{self.device.name}] Stopping previous command...")
            self.stop_event.set()
            self.thread.join()

        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run_command, args=(mode, self.stop_event))
        self.thread.start()

    def _run_command(self, mode: Command, stop_event):
        print(f"[{self.device.name}] Executing {mode.__class__.__name__}")
        mode.execute(self.device, stop_event)

    def stop(self):
        if self.thread and self.thread.is_alive():
            self.stop_event.set()
            self.thread.join()

class ServoController(BaseController):
    pass

class FanController(BaseController):
    pass
