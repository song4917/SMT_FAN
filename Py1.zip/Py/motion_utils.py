# motion_utils.py

import time

def gradual_move(current_angle, target_angle, step=1, delay=0.01, stop_event=None, update_callback=None):
    if current_angle < target_angle:
        for angle in range(current_angle + step, target_angle + 1, step):
            if stop_event and stop_event.is_set():
                return
            if update_callback:
                update_callback(angle)
            time.sleep(delay)
    elif current_angle > target_angle:
        for angle in range(current_angle - step, target_angle - 1, -step):
            if stop_event and stop_event.is_set():
                return
            if update_callback:
                update_callback(angle)
            time.sleep(delay)
