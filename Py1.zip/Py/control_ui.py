# control_ui.py
from control_comm import ControlComm
from servo_module import Servo, ServoController, FixedMode, RotateMode
from fan_module import Fan, FanController

def simulate_ui():
    servo = Servo("Circulator Servo")
    servo_controller = ServoController(servo)

    fan = Fan("Circulator Fan")
    fan_controller = FanController(fan)

    comm = ControlComm(servo_controller, fan_controller)

    print("🔧 UI 제어 시뮬레이터 시작 (예: FIX 90, ROTATE 60, FAN 70, MODE 1, AUTO ON, EXIT)")

    try:
        while True:
            cmd = input("UI 입력 > ").strip().upper()
            if cmd == "EXIT":
                servo_controller.stop()
                fan_controller.stop()
                break

            if cmd.startswith("FIX "):
                angle = int(cmd[4:])
                comm.set_servo("fixed", angle)
            elif cmd.startswith("ROTATE "):
                delta = int(cmd[7:])
                comm.set_servo("rotate", delta)
            elif cmd.startswith("FAN "):
                speed = int(cmd[4:])
                comm.set_fan(speed=speed)
            elif cmd.startswith("MODE "):
                mode = int(cmd[5:])
                comm.set_fan(mode=mode)
            elif cmd.startswith("AUTO "):
                flag = cmd[5:] == "ON"
                comm.toggle_automation(flag)
            else:
                print("❌ 알 수 없는 명령입니다.")

    except KeyboardInterrupt:
        servo_controller.stop()
        fan_controller.stop()
        print("\n종료되었습니다.")

if __name__ == "__main__":
    simulate_ui()
