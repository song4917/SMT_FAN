import threading
from motion_utils import gradual_move

class Fan:
    def __init__(self, name="Fan"):
        self.name = name
        self.speed = 0  # 0 ~ 100%

    def set_speed_gradually(self, target_speed, step=1, delay=0.01, stop_event=None):
        print(f"[{self.name}] Changing speed from {self.speed}% to {target_speed}%")

        def update_callback(speed):
            self.speed = speed
            print(f" → Speed: {self.speed}%")

        gradual_move(
            current_angle=self.speed,
            target_angle=target_speed,
            step=step,
            delay=delay,
            stop_event=stop_event,
            update_callback=update_callback
        )

    def get_speed(self):
        return self.speed


class FanController:
    def __init__(self, fan: Fan):
        self.fan = fan
        self.origin_speed = 0  # 기준 속도
        self.thread = None
        self.stop_event = threading.Event()

    def set_speed(self, target_speed: int):
        # 기준 속도 설정
        self.origin_speed = max(0, min(100, target_speed))
        print(f"[{self.fan.name}] 기준 속도(origin) 설정: {self.origin_speed}%")
        self._start_thread(self.origin_speed)

    def set_mode(self, mode: int):
        if mode == 1:
            target = max(0, self.origin_speed - 10)
        elif mode == 2:
            target = min(100, self.origin_speed + 10)
        else:
            target = self.origin_speed
        print(f"[{self.fan.name}] Mode {mode} 적용 → 목표 속도: {target}%")
        self._start_thread(target)

    def _start_thread(self, target_speed):
        if self.thread and self.thread.is_alive():
            print(f"[{self.fan.name}] 이전 작업 중지")
            self.stop_event.set()
            self.thread.join()

        self.stop_event = threading.Event()
        self.thread = threading.Thread(
            target=self.fan.set_speed_gradually,
            args=(target_speed, 1, 0.01, self.stop_event)
        )
        self.thread.start()

    def stop(self):
        if self.thread and self.thread.is_alive():
            self.stop_event.set()
            self.thread.join()
