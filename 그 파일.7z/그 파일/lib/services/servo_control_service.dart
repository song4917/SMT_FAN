import 'dart:async';
import '../models/fan_control_state.dart';
import 'bluetooth_connection_service.dart';

class ServoControlService {
  final BluetoothConnectionService _bluetoothService = BluetoothConnectionService.instance;
  Timer? _gradualChangeTimer;
  Timer? _rotationTimer;

  // 점진적 각도 변경 (유스케이스 CFR-001 제약사항 준수)
  Future<void> changeAngleGradually({
    required int currentAngle,
    required int targetAngle,
    required String axis, // 'vertical' or 'horizontal'
    Duration stepDuration = const Duration(milliseconds: 50),
  }) async {
    _gradualChangeTimer?.cancel();

    int step = (targetAngle - currentAngle).sign;
    int current = currentAngle;

    _gradualChangeTimer = Timer.periodic(stepDuration, (timer) async {
      if (current == targetAngle) {
        timer.cancel();
        return;
      }

      current += step;

      // 유스케이스에 맞는 명령 형식으로 전송
      String command = 'SERVO_${axis.toUpperCase()}_$current';
      await _bluetoothService.sendCommand(command);

      if ((step > 0 && current >= targetAngle) ||
          (step < 0 && current <= targetAngle)) {
        current = targetAngle;
        String finalCommand = 'SERVO_${axis.toUpperCase()}_$current';
        await _bluetoothService.sendCommand(finalCommand);
        timer.cancel();
      }
    });
  }

  // 회전 모드 제어 (유스케이스 CFR-001 C, D 흐름)
  Future<void> startRotation({
    required String axis,
    required int minAngle,
    required int maxAngle,
    Duration rotationSpeed = const Duration(milliseconds: 100),
  }) async {
    _rotationTimer?.cancel();

    int current = minAngle;
    int direction = 1;

    _rotationTimer = Timer.periodic(rotationSpeed, (timer) async {
      current += direction * 3; // 3도씩 이동 (유스케이스 명세서 기준)

      if (current >= maxAngle) {
        current = maxAngle;
        direction = -1;
      } else if (current <= minAngle) {
        current = minAngle;
        direction = 1;
      }

      // 회전 범위 내로 순환하도록 계산된 각도 전송
      String command = 'SERVO_${axis.toUpperCase()}_ROTATE_$current';
      await _bluetoothService.sendCommand(command);
    });
  }

  // 자동화 모드 회전 (유스케이스 CFR-001 D 흐름)
  Future<void> startAutomationRotation({
    required int maxVerticalAngle,
    required int maxHorizontalAngle,
  }) async {
    // 적외선 헤드 서보모터로 신호 전송
    String irCommand = 'IR_SERVO_AUTO_START_V${maxVerticalAngle}_H$maxHorizontalAngle';
    await _bluetoothService.sendCommand(irCommand);

    // 회전 범위 내로 순환 시작
    await startRotation(
      axis: 'vertical',
      minAngle: 0,
      maxAngle: maxVerticalAngle,
    );

    await startRotation(
      axis: 'horizontal',
      minAngle: 0,
      maxAngle: maxHorizontalAngle,
    );
  }

  // 회전 정지
  void stopRotation() {
    _gradualChangeTimer?.cancel();
    _rotationTimer?.cancel();
  }

  // 유효 범위 검증 및 조정 (유스케이스 대안 조건)
  int validateAngle(int angle, int maxAngle) {
    if (angle < 0) return 0;
    if (angle > maxAngle) return maxAngle;
    if (angle > 180) return 180; // 서보모터 최대 각도
    return angle;
  }

  // 전원 끄기 시 0도로 복귀 (유스케이스 CFR-001 E 흐름)
  Future<void> returnToZero() async {
    // 서큘레이터 헤드 0도로 복귀
    await changeAngleGradually(
      currentAngle: 90,
      targetAngle: 0,
      axis: 'vertical',
    );

    await changeAngleGradually(
      currentAngle: 90,
      targetAngle: 0,
      axis: 'horizontal',
    );

    // 적외선 헤드도 0도로 복귀
    await _bluetoothService.sendCommand('IR_SERVO_VERTICAL_0');
    await _bluetoothService.sendCommand('IR_SERVO_HORIZONTAL_0');
  }

  // 고정 모드 각도 설정
  Future<void> setFixedAngle(String axis, int angle) async {
    String command = 'SERVO_${axis.toUpperCase()}_FIXED_$angle';
    await _bluetoothService.sendCommand(command);
  }

  // 회전 모드 범위 설정
  Future<void> setRotationRange(String axis, int minAngle, int maxAngle) async {
    String command = 'SERVO_${axis.toUpperCase()}_RANGE_${minAngle}_$maxAngle';
    await _bluetoothService.sendCommand(command);
  }
}
