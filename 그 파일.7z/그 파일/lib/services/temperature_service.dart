import 'dart:async';
import 'dart:math';
import '../models/temperature_data.dart';
import 'bluetooth_connection_service.dart';

class TemperatureService {
  final BluetoothConnectionService _bluetoothService = BluetoothConnectionService.instance;
  TemperatureData? _temperatureData;
  Timer? _measurementTimer;
  StreamController<TemperatureData> _temperatureController = StreamController.broadcast();

  // CFR-003 관련 변수들
  int _currentVerticalAngle = 0;
  int _currentHorizontalAngle = 0;
  int _maxVerticalAngle = 180;
  int _maxHorizontalAngle = 180;
  bool _isAutoMode = false;

  Stream<TemperatureData> get temperatureStream => _temperatureController.stream;

  // CFR-003: 적외선 처리 시작
  void startTemperatureMeasurement({
    required int maxVerticalAngle,
    required int maxHorizontalAngle,
    int measurementInterval = 3, // 3도마다 측정 (유스케이스 명세서 기준)
  }) {
    _maxVerticalAngle = maxVerticalAngle;
    _maxHorizontalAngle = maxHorizontalAngle;

    // CFR-003 흐름 3: 2차원 배열 초기화
    int verticalSteps = (maxVerticalAngle / measurementInterval).ceil();
    int horizontalSteps = (maxHorizontalAngle / measurementInterval).ceil();

    _temperatureData = TemperatureData(
      temperatureMap: List.generate(
        verticalSteps,
            (i) => List.generate(horizontalSteps, (j) => 25.0), // 기본 온도 25도
      ),
      threshold: 30.0, // 특정 온도 기준값
    );

    _startMeasurementCycle(maxVerticalAngle, maxHorizontalAngle, measurementInterval);
  }

  // CFR-003 흐름 1-4: 측정 사이클 시작
  void _startMeasurementCycle(int maxVertical, int maxHorizontal, int interval) {
    _currentVerticalAngle = 0;
    _currentHorizontalAngle = 0;

    _measurementTimer = Timer.periodic(Duration(seconds: 2), (timer) async {
      // CFR-003 흐름 1: '서보모터 구동'에서 적외선 서보모터 각도 값을 받음
      await _bluetoothService.sendCommand('IR_SERVO_V${_currentVerticalAngle}_H$_currentHorizontalAngle');

      // CFR-003 흐름 2: 각도(3도)마다 적외선 온도 센서를 통해 온도 측정
      await _bluetoothService.sendCommand('MEASURE_TEMP_AT_${_currentVerticalAngle}_$_currentHorizontalAngle');

      // 시뮬레이션된 온도 데이터 (실제로는 라즈베리파이에서 수신)
      double simulatedTemp = _generateSimulatedTemperature(_currentVerticalAngle, _currentHorizontalAngle);

      // CFR-003 흐름 3: 측정된 온도 값을 해당 각도에 맞는 배열에 추가(수정)
      int arrayX = (_currentVerticalAngle / interval).floor();
      int arrayY = (_currentHorizontalAngle / interval).floor();
      updateTemperature(arrayX, arrayY, simulatedTemp);

      // 다음 위치 계산
      _currentHorizontalAngle += interval;
      if (_currentHorizontalAngle > maxHorizontal) {
        _currentHorizontalAngle = 0;
        _currentVerticalAngle += interval;
        if (_currentVerticalAngle > maxVertical) {
          _currentVerticalAngle = 0;
          // CFR-003 흐름 4: 2차원 배열 전체가 추가(수정)이 되었다면 배열에서 특정 온도보다 높은 포인트 확인 후 최단 경로 탐색
          _analyzeHotSpotsAndNavigate();
        }
      }
    });
  }

  // CFR-003: 온도 데이터 업데이트 (이상치 필터링 포함)
  void updateTemperature(int verticalIndex, int horizontalIndex, double temperature) {
    if (_temperatureData != null) {
      // CFR-003 대안: 온도 측정 시 이상치가 감지되면 이웃 값으로 대체함
      double filteredTemp = _filterAnomalousValue(verticalIndex, horizontalIndex, temperature);

      _temperatureData!.updateTemperature(verticalIndex, horizontalIndex, filteredTemp);
      _temperatureController.add(_temperatureData!);
    }
  }

  // CFR-003 대안: 이상치 필터링
  double _filterAnomalousValue(int x, int y, double temperature) {
    if (_temperatureData == null) return temperature;

    // 주변 온도와 비교하여 이상치 감지
    List<double> neighborTemps = [];

    for (int dx = -1; dx <= 1; dx++) {
      for (int dy = -1; dy <= 1; dy++) {
        int nx = x + dx;
        int ny = y + dy;

        if (nx >= 0 && nx < _temperatureData!.temperatureMap.length &&
            ny >= 0 && ny < _temperatureData!.temperatureMap[nx].length &&
            !(dx == 0 && dy == 0)) {
          neighborTemps.add(_temperatureData!.temperatureMap[nx][ny]);
        }
      }
    }

    if (neighborTemps.isNotEmpty) {
      double avgNeighbor = neighborTemps.reduce((a, b) => a + b) / neighborTemps.length;

      // 주변 평균과 10도 이상 차이나면 이상치로 판단하여 이웃 값으로 대체
      if ((temperature - avgNeighbor).abs() > 10.0) {
        return avgNeighbor;
      }
    }

    return temperature;
  }

  // CFR-003 흐름 4-8: 고온 지점 분석 및 최적 경로 계산
  void _analyzeHotSpotsAndNavigate() {
    if (_temperatureData == null) return;

    List<Point> hotSpots = _temperatureData!.findHotSpots();

    if (hotSpots.isNotEmpty) {
      // CFR-003 흐름 5: 포인트의 각도 값을 '서보모터 구동'으로 출력
      Point? targetPoint = _findNearestHotSpot(hotSpots);

      if (targetPoint != null) {
        _temperatureData!.currentTarget = targetPoint;

        // 포인트를 실제 각도로 변환
        int targetVertical = targetPoint.x * 3; // 3도 간격
        int targetHorizontal = targetPoint.y * 3;

        // 서큘레이터 헤드를 해당 위치로 이동 명령
        _bluetoothService.sendCommand('TARGET_SERVO_V${targetVertical}_H$targetHorizontal');

        // CFR-003 흐름 6: 현재 헤드 서보모터 각도와 출력된 포인트의 각도를 비교
        _compareAnglesAndAdjustFanSpeed(targetVertical, targetHorizontal);
      }
    }
  }

  // CFR-003 흐름 6.1, 6.2: 각도 비교 및 팬 속도 조정
  void _compareAnglesAndAdjustFanSpeed(int targetVertical, int targetHorizontal) {
    // 현재 헤드 서보모터 각도 가져오기 (시뮬레이션)
    int currentVertical = _currentVerticalAngle;
    int currentHorizontal = _currentHorizontalAngle;

    // CFR-003 흐름 6.1: 각도가 동일할 경우
    if (currentVertical == targetVertical && currentHorizontal == targetHorizontal) {
      // 딜레이(예: 3초) 후 다음 포인트를 출력 및 적외선 팬 속도 조정 값을 1로 출력
      Timer(Duration(seconds: 3), () {
        _bluetoothService.sendCommand('FAN_SPEED_ADJUST_1'); // 목표에 도달 (+10%)
        _findNextHotSpot();
      });
    } else {
      // CFR-003 흐름 6.2: 각도가 동일하지 않을 경우 적외선 팬 속도 조정 값을 2로 출력
      _bluetoothService.sendCommand('FAN_SPEED_ADJUST_2'); // 목표에 접근 중 (-10%)
    }
  }

  // 가장 가까운 고온 지점 찾기 (최단 경로 탐색)
  Point? _findNearestHotSpot(List<Point> hotSpots) {
    if (hotSpots.isEmpty) return null;

    // 현재 위치 (중앙으로 가정)
    Point currentPos = Point(
      _temperatureData!.temperatureMap.length ~/ 2,
      _temperatureData!.temperatureMap[0].length ~/ 2,
    );

    Point nearest = hotSpots.first;
    double minDistance = _calculateDistance(currentPos, nearest);

    for (Point spot in hotSpots) {
      double distance = _calculateDistance(currentPos, spot);
      if (distance < minDistance) {
        minDistance = distance;
        nearest = spot;
      }
    }

    return nearest;
  }

  // CFR-003 흐름 6.1: 다음 고온 지점 찾기
  void _findNextHotSpot() {
    if (_temperatureData == null) return;

    List<Point> hotSpots = _temperatureData!.findHotSpots();
    Point? currentTarget = _temperatureData!.currentTarget;

    if (hotSpots.length > 1 && currentTarget != null) {
      // 현재 타겟이 아닌 다른 고온 지점 찾기
      Point? nextTarget;
      for (Point spot in hotSpots) {
        if (spot != currentTarget) {
          nextTarget = spot;
          break;
        }
      }

      if (nextTarget != null) {
        _temperatureData!.currentTarget = nextTarget;
        int targetVertical = nextTarget.x * 3;
        int targetHorizontal = nextTarget.y * 3;
        _bluetoothService.sendCommand('TARGET_SERVO_V${targetVertical}_H$targetHorizontal');
      }
    }
  }

  // 거리 계산 (최단 경로 탐색용)
  double _calculateDistance(Point a, Point b) {
    return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2));
  }

  // 시뮬레이션된 온도 데이터 생성
  double _generateSimulatedTemperature(int vertical, int horizontal) {
    // CFR-003 제약사항: 온도 측정은 지정된 동작 온도 범위 내에서만 처리
    double baseTemp = 25.0;
    double positionEffect = (vertical + horizontal) * 0.1;
    double randomNoise = (Random().nextDouble() - 0.5) * 2;

    // 특정 위치에 고온 지점 시뮬레이션
    if ((vertical >= 30 && vertical <= 60) && (horizontal >= 45 && horizontal <= 75)) {
      baseTemp += 8.0; // 고온 지역
    }

    double finalTemp = baseTemp + positionEffect + randomNoise;

    // 동작 온도 범위 제한 (0-50도)
    if (finalTemp < 0) finalTemp = 0;
    if (finalTemp > 50) finalTemp = 50;

    return finalTemp;
  }

  // CFR-003: 온도 측정 중지
  void stopTemperatureMeasurement() {
    _measurementTimer?.cancel();
  }

  // 현재 온도 데이터 가져오기
  TemperatureData? getCurrentTemperatureData() {
    return _temperatureData;
  }

  void dispose() {
    _measurementTimer?.cancel();
    _temperatureController.close();
  }
}
