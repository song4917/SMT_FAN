import 'package:flutter_bluetooth_serial_ble/flutter_bluetooth_serial_ble.dart';
import 'dart:convert';
import 'dart:typed_data';
import '../models/fan_control_state.dart';

class BluetoothConnectionService {
  static BluetoothConnectionService? _instance;
  BluetoothConnectionService._internal();

  static BluetoothConnectionService get instance {
    _instance ??= BluetoothConnectionService._internal();
    return _instance!;
  }

  BluetoothConnection? connection;
  bool isConnected = false;

  // 블루투스 지원 여부 확인
  Future<bool> isBluetoothSupported() async {
    try {
      BluetoothState state = await FlutterBluetoothSerial.instance.state;
      return state != BluetoothState.UNKNOWN;
    } catch (e) {
      return false;
    }
  }

  // 블루투스 활성화 상태 확인
  Future<bool> isBluetoothEnabled() async {
    BluetoothState state = await FlutterBluetoothSerial.instance.state;
    return state == BluetoothState.STATE_ON;
  }

  // 라즈베리파이 연결 (RFCOMM 방식)
  Future<Map<String, dynamic>> connectToDevice(String deviceName) async {
    try {
      // 페어링된 기기 목록에서 라즈베리파이 찾기
      List<BluetoothDevice> devices = await FlutterBluetoothSerial.instance.getBondedDevices();

      BluetoothDevice? targetDevice;
      for (BluetoothDevice device in devices) {
        if (device.name != null &&
            (device.name!.contains(deviceName) ||
                device.name!.toLowerCase().contains("raspberry") ||
                device.name!.toLowerCase().contains("raspi") ||
                device.name!.contains("RaspiServer"))) {
          targetDevice = device;
          break;
        }
      }

      if (targetDevice == null) {
        return {'success': false, 'error': '$deviceName을 페어링된 기기에서 찾을 수 없음'};
      }

      // RFCOMM 연결 시도
      connection = await BluetoothConnection.toAddress(targetDevice.address);
      isConnected = true;

      // 연결 상태 모니터링
      connection!.input!.listen((Uint8List data) {
        // 라즈베리파이로부터 데이터 수신 처리
        String received = String.fromCharCodes(data);
        print('라즈베리파이로부터 수신: $received');
      }).onDone(() {
        isConnected = false;
        print('라즈베리파이 연결 해제됨');
      });

      return {
        'success': true,
        'deviceName': targetDevice.name,
        'deviceAddress': targetDevice.address,
      };

    } catch (e) {
      return {'success': false, 'error': '라즈베리파이 연결 실패: $e'};
    }
  }

  // 라즈베리파이로 제어 데이터 전송 (유스케이스 명세서 기반)
  Future<bool> sendControlData(FanControlState state) async {
    try {
      if (connection != null && isConnected) {
        // 유스케이스에 맞는 JSON 형식으로 전송
        Map<String, dynamic> controlData = {
          'power': state.powerOn ? 1 : 0,
          'fan_speed': state.fanSpeed,
          'vertical_fixed': state.verticalFixed ? 1 : 0,
          'horizontal_fixed': state.horizontalFixed ? 1 : 0,
          'vertical_angle': state.verticalAngle,
          'horizontal_angle': state.horizontalAngle,
          'max_vertical_angle': state.maxVerticalAngle,
          'max_horizontal_angle': state.maxHorizontalAngle,
          'auto_mode': state.autoMode ? 1 : 0,
          'timer_seconds': state.timer.inSeconds,
        };

        String jsonData = jsonEncode(controlData);
        connection!.output.add(Uint8List.fromList(utf8.encode(jsonData + '\n')));
        await connection!.output.allSent;

        return true;
      }
      return false;
    } catch (e) {
      print('데이터 전송 실패: $e');
      return false;
    }
  }

  // 개별 명령 전송 (유스케이스 명세서 기반)
  Future<bool> sendCommand(String command) async {
    try {
      if (connection != null && isConnected) {
        connection!.output.add(Uint8List.fromList(utf8.encode(command + '\n')));
        await connection!.output.allSent;
        return true;
      }
      return false;
    } catch (e) {
      print('명령 전송 실패: $e');
      return false;
    }
  }

  // 페어링된 기기 목록 (라즈베리파이 필터링)
  Future<List<Map<String, String>>> getPairedDevices() async {
    List<Map<String, String>> deviceList = [];

    try {
      List<BluetoothDevice> devices = await FlutterBluetoothSerial.instance.getBondedDevices();

      for (BluetoothDevice device in devices) {
        deviceList.add({
          'name': device.name ?? 'Unknown Device',
          'address': device.address,
          'isRaspberryPi': (device.name != null &&
              (device.name!.toLowerCase().contains('raspberry') ||
                  device.name!.toLowerCase().contains('raspi') ||
                  device.name!.toLowerCase().contains('pi'))) ? 'true' : 'false',
        });
      }
    } catch (e) {
      print('페어링된 기기 조회 실패: $e');
    }

    return deviceList;
  }

  // 연결 해제
  Future<void> disconnect() async {
    try {
      if (connection != null) {
        await connection!.close();
        connection = null;
        isConnected = false;
      }
    } catch (e) {
      print('연결 해제 실패: $e');
    }
  }

  // 연결 상태 스트림
  Stream<bool> get connectionState {
    return Stream.periodic(Duration(seconds: 1), (_) => isConnected);
  }
}
