import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/main_control_screen.dart';
import 'services/bluetooth_connection_service.dart';
import 'services/servo_control_service.dart';
import 'services/temperature_service.dart';
import 'models/fan_control_state.dart';

void main() {
  runApp(SmartFanApp());
}

class SmartFanApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => FanControlProvider()),
        Provider(create: (_) => BluetoothConnectionService.instance),
        Provider(create: (_) => ServoControlService()),
        Provider(create: (_) => TemperatureService()),
      ],
      child: MaterialApp(
        title: 'Smart Fan Controller',
        theme: ThemeData(
          primarySwatch: Colors.blue,
          visualDensity: VisualDensity.adaptivePlatformDensity,
          fontFamily: 'Roboto',
        ),
        home: SplashScreen(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}

class FanControlProvider extends ChangeNotifier {
  FanControlState _state = FanControlState();

  FanControlState get state => _state;

  void updateState(FanControlState newState) {
    _state = newState;
    notifyListeners();
  }

  void updatePower(bool power) {
    _state = _state.copyWith(powerOn: power);
    notifyListeners();
  }

  void updateFanSpeed(int speed) {
    _state = _state.copyWith(fanSpeed: speed);
    notifyListeners();
  }

  void updateVerticalFixed(bool fixed) {
    _state = _state.copyWith(verticalFixed: fixed);
    notifyListeners();
  }

  void updateHorizontalFixed(bool fixed) {
    _state = _state.copyWith(horizontalFixed: fixed);
    notifyListeners();
  }

  void updateVerticalAngle(int angle) {
    _state = _state.copyWith(verticalAngle: angle);
    notifyListeners();
  }

  void updateHorizontalAngle(int angle) {
    _state = _state.copyWith(horizontalAngle: angle);
    notifyListeners();
  }

  void updateMaxVerticalAngle(int angle) {
    _state = _state.copyWith(maxVerticalAngle: angle);
    notifyListeners();
  }

  void updateMaxHorizontalAngle(int angle) {
    _state = _state.copyWith(maxHorizontalAngle: angle);
    notifyListeners();
  }

  void updateAutoMode(bool auto) {
    _state = _state.copyWith(autoMode: auto);
    notifyListeners();
  }

  void updateTimer(Duration timer) {
    _state = _state.copyWith(timer: timer);
    notifyListeners();
  }

  void updateConnectionStatus(bool connected) {
    _state = _state.copyWith(isConnected: connected);
    notifyListeners();
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(seconds: 2),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(_animationController);

    _animationController.forward();

    Future.delayed(Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => MainControlScreen()),
      );
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[900],
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.air,
                size: 120,
                color: Colors.white,
              ),
              SizedBox(height: 20),
              Text(
                'Smart Fan Controller',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 10),
              Text(
                'Temperature-Based Control System',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white70,
                ),
              ),
              SizedBox(height: 40),
              CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
