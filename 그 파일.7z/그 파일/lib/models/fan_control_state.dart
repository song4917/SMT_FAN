class FanControlState {
  bool powerOn;
  int fanSpeed; // 1-100
  bool verticalFixed;
  bool horizontalFixed;
  int verticalAngle; // 0-180
  int horizontalAngle; // 0-180
  int maxVerticalAngle; // 0-180
  int maxHorizontalAngle; // 0-180
  bool autoMode;
  Duration timer;
  bool isConnected;

  FanControlState({
    this.powerOn = false,
    this.fanSpeed = 50,
    this.verticalFixed = true,
    this.horizontalFixed = true,
    this.verticalAngle = 90,
    this.horizontalAngle = 90,
    this.maxVerticalAngle = 180,
    this.maxHorizontalAngle = 180,
    this.autoMode = false,
    this.timer = const Duration(minutes: 30),
    this.isConnected = false,
  });

  FanControlState copyWith({
    bool? powerOn,
    int? fanSpeed,
    bool? verticalFixed,
    bool? horizontalFixed,
    int? verticalAngle,
    int? horizontalAngle,
    int? maxVerticalAngle,
    int? maxHorizontalAngle,
    bool? autoMode,
    Duration? timer,
    bool? isConnected,
  }) {
    return FanControlState(
      powerOn: powerOn ?? this.powerOn,
      fanSpeed: fanSpeed ?? this.fanSpeed,
      verticalFixed: verticalFixed ?? this.verticalFixed,
      horizontalFixed: horizontalFixed ?? this.horizontalFixed,
      verticalAngle: verticalAngle ?? this.verticalAngle,
      horizontalAngle: horizontalAngle ?? this.horizontalAngle,
      maxVerticalAngle: maxVerticalAngle ?? this.maxVerticalAngle,
      maxHorizontalAngle: maxHorizontalAngle ?? this.maxHorizontalAngle,
      autoMode: autoMode ?? this.autoMode,
      timer: timer ?? this.timer,
      isConnected: isConnected ?? this.isConnected,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'power': powerOn ? 1 : 0,
      'fan_speed': fanSpeed,
      'vertical_fixed': verticalFixed ? 1 : 0,
      'horizontal_fixed': horizontalFixed ? 1 : 0,
      'vertical_angle': verticalAngle,
      'horizontal_angle': horizontalAngle,
      'max_vertical_angle': maxVerticalAngle,
      'max_horizontal_angle': maxHorizontalAngle,
      'auto_mode': autoMode ? 1 : 0,
      'timer_seconds': timer.inSeconds,
    };
  }
}
