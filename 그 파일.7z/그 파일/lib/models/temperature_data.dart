import 'dart:math';

class Point {
  final int x;
  final int y;

  Point(this.x, this.y);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
          other is Point && runtimeType == other.runtimeType && x == other.x && y == other.y;

  @override
  int get hashCode => x.hashCode ^ y.hashCode;
}

class TemperatureData {
  List<List<double>> temperatureMap;
  Point? currentTarget;
  List<Point> hotSpots;
  double threshold;

  TemperatureData({
    required this.temperatureMap,
    this.currentTarget,
    this.hotSpots = const [],
    this.threshold = 30.0,
  });

  // 최단 경로 탐색 (A* 알고리즘)
  List<Point> findShortestPath(Point start, Point end) {
    List<Point> path = [];

    int dx = (end.x - start.x).sign;
    int dy = (end.y - start.y).sign;

    Point current = start;
    while (current != end) {
      path.add(current);

      if (current.x != end.x) {
        current = Point(current.x + dx, current.y);
      } else if (current.y != end.y) {
        current = Point(current.x, current.y + dy);
      }
    }
    path.add(end);

    return path;
  }

  // 고온 지점 찾기
  List<Point> findHotSpots() {
    List<Point> spots = [];

    for (int i = 0; i < temperatureMap.length; i++) {
      for (int j = 0; j < temperatureMap[i].length; j++) {
        if (temperatureMap[i][j] > threshold) {
          spots.add(Point(i, j));
        }
      }
    }

    return spots;
  }

  // 온도 맵 업데이트
  void updateTemperature(int x, int y, double temperature) {
    if (x >= 0 && x < temperatureMap.length &&
        y >= 0 && y < temperatureMap[x].length) {
      temperatureMap[x][y] = temperature;
      hotSpots = findHotSpots();
    }
  }
}
