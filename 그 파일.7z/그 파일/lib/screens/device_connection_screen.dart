import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/bluetooth_connection_service.dart';
import '../main.dart';

class DeviceConnectionScreen extends StatefulWidget {
  @override
  _DeviceConnectionScreenState createState() => _DeviceConnectionScreenState();
}

class _DeviceConnectionScreenState extends State<DeviceConnectionScreen>
    with TickerProviderStateMixin {
  late AnimationController _scanAnimationController;
  late AnimationController _connectionAnimationController;
  late Animation<double> _scanAnimation;
  late Animation<double> _connectionAnimation;

  List<Map<String, String>> _availableDevices = [];
  List<Map<String, String>> _pairedDevices = [];
  bool _isScanning = false;
  bool _isConnecting = false;
  String? _connectingDeviceId;

  @override
  void initState() {
    super.initState();
    _scanAnimationController = AnimationController(
      duration: Duration(seconds: 2),
      vsync: this,
    );
    _connectionAnimationController = AnimationController(
      duration: Duration(milliseconds: 500),
      vsync: this,
    );

    _scanAnimation = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _scanAnimationController, curve: Curves.easeInOut));
    _connectionAnimation = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _connectionAnimationController, curve: Curves.easeInOut));

    _loadPairedDevices();
  }

  @override
  void dispose() {
    _scanAnimationController.dispose();
    _connectionAnimationController.dispose();
    super.dispose();
  }

  Future<void> _loadPairedDevices() async {
    final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);
    final devices = await bluetoothService.getPairedDevices();
    setState(() {
      _pairedDevices = devices;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text('기기 연결'),
        backgroundColor: Colors.blue[800],
        elevation: 0,
        actions: [
          IconButton(
            icon: AnimatedBuilder(
              animation: _scanAnimation,
              builder: (context, child) {
                return Transform.rotate(
                  angle: _scanAnimation.value * 2 * 3.14159,
                  child: Icon(_isScanning ? Icons.bluetooth_searching : Icons.bluetooth),
                );
              },
            ),
            onPressed: _isScanning ? null : _startScan,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 연결 상태 카드 (BFR-001: 제어 정보 통신 상태)
            _buildConnectionStatusCard(),
            SizedBox(height: 16),

            // 라즈베리파이 우선 표시 카드
            _buildRaspberryPiCard(),
            SizedBox(height: 16),

            // 페어링된 기기 목록
            _buildPairedDevicesCard(),
            SizedBox(height: 16),

            // 사용 가능한 기기 목록
            _buildAvailableDevicesCard(),
            SizedBox(height: 16),

            // 연결 도움말 카드
            _buildHelpCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildConnectionStatusCard() {
    return Consumer<FanControlProvider>(
      builder: (context, provider, child) {
        final isConnected = provider.state.isConnected;

        return Card(
          elevation: 8,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Container(
            padding: EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: isConnected
                    ? [Colors.green[400]!, Colors.green[600]!]
                    : [Colors.grey[400]!, Colors.grey[600]!],
              ),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(
                      isConnected ? Icons.bluetooth_connected : Icons.bluetooth_disabled,
                      color: Colors.white,
                      size: 32,
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isConnected ? '라즈베리파이 연결됨' : '연결 안됨',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            isConnected
                                ? 'BFR-001: 제어 정보 통신 활성화'
                                : '라즈베리파이에 연결해주세요.',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                if (isConnected) ...[
                  SizedBox(height: 16),
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info, color: Colors.white, size: 16),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '양방향 블루투스 통신이 활성화되었습니다.',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _disconnect,
                          icon: Icon(Icons.bluetooth_disabled),
                          label: Text('연결 해제'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: Colors.green[600],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  // 라즈베리파이 우선 표시 카드
  Widget _buildRaspberryPiCard() {
    final raspberryPiDevices = _pairedDevices.where((device) =>
    device['isRaspberryPi'] == 'true').toList();

    if (raspberryPiDevices.isEmpty) return Container();

    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.purple[50]!, Colors.purple[100]!],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.memory, color: Colors.purple[600], size: 24),
                SizedBox(width: 8),
                Text(
                  '라즈베리파이 기기',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.purple[800],
                  ),
                ),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.purple[200],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '우선 연결',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: Colors.purple[800],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),

            ...raspberryPiDevices.map((device) => Container(
              margin: EdgeInsets.only(bottom: 8),
              child: _buildDeviceListItem(device, isPaired: true, isRaspberryPi: true),
            )).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildPairedDevicesCard() {
    final otherDevices = _pairedDevices.where((device) =>
    device['isRaspberryPi'] != 'true').toList();

    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.devices, color: Colors.blue[600], size: 24),
                SizedBox(width: 8),
                Text(
                  '기타 페어링된 기기',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
                Spacer(),
                IconButton(
                  icon: Icon(Icons.refresh, color: Colors.blue[600]),
                  onPressed: _loadPairedDevices,
                ),
              ],
            ),
            SizedBox(height: 16),

            if (otherDevices.isEmpty)
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info, color: Colors.grey[600]),
                    SizedBox(width: 8),
                    Text(
                      '기타 페어링된 기기가 없습니다.',
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  ],
                ),
              )
            else
              ...(otherDevices.map((device) => _buildDeviceListItem(
                device,
                isPaired: true,
                isRaspberryPi: false,
              )).toList()),
          ],
        ),
      ),
    );
  }

  Widget _buildAvailableDevicesCard() {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.search, color: Colors.green[600], size: 24),
                SizedBox(width: 8),
                Text(
                  '사용 가능한 기기',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
                Spacer(),
                AnimatedBuilder(
                  animation: _scanAnimation,
                  builder: (context, child) {
                    return ElevatedButton.icon(
                      onPressed: _isScanning ? null : _startScan,
                      icon: Transform.rotate(
                        angle: _scanAnimation.value * 2 * 3.14159,
                        child: Icon(Icons.search),
                      ),
                      label: Text(_isScanning ? '스캔 중...' : '스캔'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[600],
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
            SizedBox(height: 16),

            if (_isScanning)
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                    SizedBox(width: 12),
                    Text(
                      '라즈베리파이를 포함한 주변 기기를 검색하고 있습니다...',
                      style: TextStyle(color: Colors.blue[700]),
                    ),
                  ],
                ),
              )
            else if (_availableDevices.isEmpty)
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info, color: Colors.grey[600]),
                    SizedBox(width: 8),
                    Text(
                      '스캔 버튼을 눌러 주변 기기를 검색하세요.',
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  ],
                ),
              )
            else
              ...(_availableDevices.map((device) => _buildDeviceListItem(
                device,
                isPaired: false,
                isRaspberryPi: device['name']?.toLowerCase().contains('raspberry') ?? false,
              )).toList()),
          ],
        ),
      ),
    );
  }

  Widget _buildDeviceListItem(Map<String, String> device, {
    required bool isPaired,
    required bool isRaspberryPi
  }) {
    final isConnecting = _isConnecting && _connectingDeviceId == device['address'];

    return Container(
      margin: EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isRaspberryPi ? Colors.purple[200]! : Colors.grey[200]!,
          width: isRaspberryPi ? 2 : 1,
        ),
      ),
      child: ListTile(
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: isRaspberryPi
                ? Colors.purple[100]
                : isPaired ? Colors.blue[100] : Colors.green[100],
            shape: BoxShape.circle,
          ),
          child: Icon(
            isRaspberryPi
                ? Icons.memory
                : isPaired ? Icons.bluetooth_connected : Icons.bluetooth,
            color: isRaspberryPi
                ? Colors.purple[600]
                : isPaired ? Colors.blue[600] : Colors.green[600],
          ),
        ),
        title: Text(
          device['name'] ?? 'Unknown Device',
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 16,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              device['address'] ?? '',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 12,
              ),
            ),
            Row(
              children: [
                if (isPaired)
                  Container(
                    margin: EdgeInsets.only(top: 4, right: 8),
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.blue[100],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '페어링됨',
                      style: TextStyle(
                        color: Colors.blue[700],
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                if (isRaspberryPi)
                  Container(
                    margin: EdgeInsets.only(top: 4),
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.purple[100],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '라즈베리파이',
                      style: TextStyle(
                        color: Colors.purple[700],
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
        trailing: isConnecting
            ? SizedBox(
          width: 20,
          height: 20,
          child: CircularProgressIndicator(strokeWidth: 2),
        )
            : ElevatedButton(
          onPressed: () => _connectToDevice(device),
          child: Text('연결'),
          style: ElevatedButton.styleFrom(
            backgroundColor: isRaspberryPi ? Colors.purple[600] : Colors.blue[600],
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHelpCard() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.help_outline, color: Colors.orange[600], size: 24),
                SizedBox(width: 8),
                Text(
                  '라즈베리파이 연결 가이드',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),

            _buildHelpItem(
              '1. 라즈베리파이의 전원이 켜져 있는지 확인하세요.',
              Icons.power_settings_new,
            ),
            _buildHelpItem(
              '2. 라즈베리파이의 블루투스가 활성화되어 있는지 확인하세요.',
              Icons.bluetooth_searching,
            ),
            _buildHelpItem(
              '3. 스캔 버튼을 눌러 라즈베리파이를 검색하세요.',
              Icons.search,
            ),
            _buildHelpItem(
              '4. 목록에서 라즈베리파이를 찾아 연결 버튼을 누르세요.',
              Icons.memory,
            ),
            _buildHelpItem(
              '5. BFR-001 제어 정보 통신이 활성화되면 완료입니다.',
              Icons.check_circle,
            ),

            SizedBox(height: 16),

            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.amber[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.amber[200]!),
              ),
              child: Row(
                children: [
                  Icon(Icons.warning, color: Colors.amber[700], size: 20),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '연결에 문제가 있다면 라즈베리파이를 재시작하고 다시 시도해보세요.',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.amber[800],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHelpItem(String text, IconData icon) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: Colors.orange[400], size: 16),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[700],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _startScan() async {
    setState(() {
      _isScanning = true;
      _availableDevices.clear();
    });

    _scanAnimationController.repeat();

    try {
      // 시뮬레이션된 스캔 결과 (실제로는 flutter_bluetooth_serial 사용)
      await Future.delayed(Duration(seconds: 3));

      setState(() {
        _availableDevices = [
          {'name': 'RaspiServer', 'address': 'B8:27:EB:12:34:56'},
          {'name': 'raspberrypi', 'address': 'B8:27:EB:78:90:AB'},
          {'name': 'Smart Fan Pro', 'address': 'AA:BB:CC:DD:EE:FF'},
        ];
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${_availableDevices.length}개의 기기를 찾았습니다.'),
          backgroundColor: Colors.green[600],
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('스캔 실패: $e'),
          backgroundColor: Colors.red[600],
        ),
      );
    } finally {
      setState(() {
        _isScanning = false;
      });
      _scanAnimationController.stop();
    }
  }

  // BFR-001: 제어 정보 통신 연결
  Future<void> _connectToDevice(Map<String, String> device) async {
    setState(() {
      _isConnecting = true;
      _connectingDeviceId = device['address'];
    });

    _connectionAnimationController.forward();

    final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);
    final provider = Provider.of<FanControlProvider>(context, listen: false);

    try {
      final result = await bluetoothService.connectToDevice(device['name'] ?? '');

      if (result['success']) {
        provider.updateConnectionStatus(true);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.white),
                SizedBox(width: 8),
                Expanded(
                  child: Text('${device['name']}에 연결되었습니다.\nBFR-001 제어 정보 통신이 활성화되었습니다.'),
                ),
              ],
            ),
            backgroundColor: Colors.green[600],
            duration: Duration(seconds: 3),
          ),
        );

        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.error, color: Colors.white),
                SizedBox(width: 8),
                Text('연결 실패: ${result['error']}'),
              ],
            ),
            backgroundColor: Colors.red[600],
            duration: Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('연결 오류: $e'),
          backgroundColor: Colors.red[600],
        ),
      );
    } finally {
      setState(() {
        _isConnecting = false;
        _connectingDeviceId = null;
      });
      _connectionAnimationController.reverse();
    }
  }

  Future<void> _disconnect() async {
    final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);
    final provider = Provider.of<FanControlProvider>(context, listen: false);

    try {
      await bluetoothService.disconnect();
      provider.updateConnectionStatus(false);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('라즈베리파이 연결이 해제되었습니다.'),
          backgroundColor: Colors.orange[600],
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('연결 해제 실패: $e'),
          backgroundColor: Colors.red[600],
        ),
      );
    }
  }
}
