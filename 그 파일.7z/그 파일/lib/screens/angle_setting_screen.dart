import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../main.dart';
import '../services/bluetooth_connection_service.dart';
import '../services/servo_control_service.dart';

class AngleSettingScreen extends StatefulWidget {
  @override
  _AngleSettingScreenState createState() => _AngleSettingScreenState();
}

class _AngleSettingScreenState extends State<AngleSettingScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0)
        .animate(CurvedAnimation(parent: _animationController, curve: Curves.easeOut));

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<FanControlProvider>(
      builder: (context, provider, child) {
        final state = provider.state;

        return Scaffold(
          backgroundColor: Colors.grey[50],
          appBar: AppBar(
            title: Text('각도 설정'),
            backgroundColor: Colors.blue[800],
            elevation: 0,
            actions: [
              IconButton(
                icon: Icon(Icons.save),
                onPressed: () => _saveSettings(context, provider),
              ),
            ],
          ),
          body: AnimatedBuilder(
            animation: _scaleAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _scaleAnimation.value,
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    children: [
                      // 3D 시각화 카드
                      _build3DVisualizationCard(state),
                      SizedBox(height: 16),

                      // 상하 각도 설정 (AFR-001 1-E: 고정 상태의 상하 각도 제어)
                      _buildAngleControlCard(
                        '상하 각도 설정 (0-180도)',
                        Icons.swap_vert,
                        Colors.blue,
                        state.verticalAngle,
                        state.maxVerticalAngle,
                        state.verticalFixed,
                            (angle) {
                          // CFR-001: 유효 범위 검증 및 조정
                          int validAngle = _validateAngle(angle);
                          provider.updateVerticalAngle(validAngle);
                        },
                            (maxAngle) {
                          int validMaxAngle = _validateAngle(maxAngle);
                          provider.updateMaxVerticalAngle(validMaxAngle);
                        },
                            (fixed) => provider.updateVerticalFixed(fixed),
                        'vertical',
                      ),

                      SizedBox(height: 16),

                      // 좌우 각도 설정 (AFR-001 1-F: 회전 상태의 좌우 각도 제어)
                      _buildAngleControlCard(
                        '좌우 각도 설정 (0-180도)',
                        Icons.swap_horiz,
                        Colors.orange,
                        state.horizontalAngle,
                        state.maxHorizontalAngle,
                        state.horizontalFixed,
                            (angle) {
                          int validAngle = _validateAngle(angle);
                          provider.updateHorizontalAngle(validAngle);
                        },
                            (maxAngle) {
                          int validMaxAngle = _validateAngle(maxAngle);
                          provider.updateMaxHorizontalAngle(validMaxAngle);
                        },
                            (fixed) => provider.updateHorizontalFixed(fixed),
                        'horizontal',
                      ),

                      SizedBox(height: 24),

                      // 프리셋 버튼들
                      _buildPresetButtons(provider),

                      SizedBox(height: 24),

                      // 실시간 테스트 버튼
                      _buildTestButtons(context, state),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  // 유효 범위 검증 (유스케이스 대안 조건)
  int _validateAngle(int angle) {
    if (angle < 0) return 0;
    if (angle > 180) return 180;
    return angle;
  }

  Widget _build3DVisualizationCard(state) {
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        height: 200,
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.blue[50]!, Colors.blue[100]!],
          ),
        ),
        child: Column(
          children: [
            Text(
              '현재 각도 시각화',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.blue[800],
              ),
            ),
            SizedBox(height: 20),

            Expanded(
              child: Row(
                children: [
                  // 상하 각도 표시
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          '상하',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.blue[600],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: 8),
                        Expanded(
                          child: CustomPaint(
                            painter: AngleVisualizationPainter(
                              angle: state.verticalAngle,
                              maxAngle: state.maxVerticalAngle,
                              isVertical: true,
                              color: Colors.blue[600]!,
                            ),
                            child: Container(),
                          ),
                        ),
                        Text(
                          '${state.verticalAngle}°',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.blue[700],
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(width: 20),

                  // 좌우 각도 표시
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          '좌우',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.orange[600],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: 8),
                        Expanded(
                          child: CustomPaint(
                            painter: AngleVisualizationPainter(
                              angle: state.horizontalAngle,
                              maxAngle: state.maxHorizontalAngle,
                              isVertical: false,
                              color: Colors.orange[600]!,
                            ),
                            child: Container(),
                          ),
                        ),
                        Text(
                          '${state.horizontalAngle}°',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.orange[700],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAngleControlCard(
      String title,
      IconData icon,
      Color color,
      int currentAngle,
      int maxAngle,
      bool isFixed,
      Function(int) onAngleChanged,
      Function(int) onMaxAngleChanged,
      Function(bool) onFixedChanged,
      String axis,
      ) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 24),
                SizedBox(width: 8),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: isFixed ? color.withOpacity(0.1) : Colors.orange.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    isFixed ? '고정 모드' : '회전 모드',
                    style: TextStyle(
                      color: isFixed ? color : Colors.orange[700],
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: 20),

            // 고정/회전 토글 (AFR-001 1-D: 구동 제어)
            Row(
              children: [
                Text(
                  '동작 모드',
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                Spacer(),
                Switch(
                  value: isFixed,
                  onChanged: onFixedChanged,
                  activeColor: color,
                ),
                SizedBox(width: 8),
                Text(
                  isFixed ? '고정' : '회전',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: isFixed ? color : Colors.orange[700],
                  ),
                ),
              ],
            ),

            SizedBox(height: 20),

            // 현재 각도 설정 (0-180도 범위)
            Text(
              isFixed ? '고정 각도 (0-180도)' : '회전 중심 각도 (0-180도)',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.grey[700],
              ),
            ),
            SizedBox(height: 8),

            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: color,
                inactiveTrackColor: color.withOpacity(0.3),
                thumbColor: color,
                overlayColor: color.withOpacity(0.2),
                thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12),
                overlayShape: RoundSliderOverlayShape(overlayRadius: 20),
                valueIndicatorColor: color,
                valueIndicatorTextStyle: TextStyle(color: Colors.white),
              ),
              child: Slider(
                value: currentAngle.toDouble(),
                min: 0,
                max: 180,
                divisions: 36,
                label: '${currentAngle}°',
                onChanged: (value) => onAngleChanged(value.round()),
              ),
            ),

            SizedBox(height: 16),

            // 최대 각도 설정 (회전 모드일 때만)
            if (!isFixed) ...[
              Text(
                '회전 범위 (최대 각도)',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey[700],
                ),
              ),
              SizedBox(height: 8),

              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: Colors.orange[400],
                  inactiveTrackColor: Colors.orange[100],
                  thumbColor: Colors.orange[600],
                  overlayColor: Colors.orange[200],
                  thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12),
                  overlayShape: RoundSliderOverlayShape(overlayRadius: 20),
                  valueIndicatorColor: Colors.orange[600],
                  valueIndicatorTextStyle: TextStyle(color: Colors.white),
                ),
                child: Slider(
                  value: maxAngle.toDouble(),
                  min: currentAngle.toDouble(),
                  max: 180,
                  divisions: (180 - currentAngle),
                  label: '${maxAngle}°',
                  onChanged: (value) => onMaxAngleChanged(value.round()),
                ),
              ),

              Text(
                '회전 범위: ${currentAngle}° ~ ${maxAngle}°',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildPresetButtons(FanControlProvider provider) {
    final presets = [
      {'name': '정면', 'v': 90, 'h': 90},
      {'name': '위쪽', 'v': 45, 'h': 90},
      {'name': '아래쪽', 'v': 135, 'h': 90},
      {'name': '왼쪽', 'v': 90, 'h': 45},
      {'name': '오른쪽', 'v': 90, 'h': 135},
      {'name': '초기화', 'v': 0, 'h': 0},
    ];

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '빠른 설정',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            SizedBox(height: 12),

            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: presets.map((preset) {
                return ElevatedButton(
                  onPressed: () {
                    // 유효 범위 검증 적용
                    int validV = _validateAngle(preset['v'] as int);
                    int validH = _validateAngle(preset['h'] as int);

                    provider.updateVerticalAngle(validV);
                    provider.updateHorizontalAngle(validH);

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('${preset['name']} 위치로 설정되었습니다.'),
                        duration: Duration(seconds: 1),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[50],
                    foregroundColor: Colors.blue[700],
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  child: Text(preset['name'] as String),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTestButtons(BuildContext context, state) {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () => _testMovement(context, 'vertical'),
            icon: Icon(Icons.swap_vert),
            label: Text('상하 테스트'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue[600],
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () => _testMovement(context, 'horizontal'),
            icon: Icon(Icons.swap_horiz),
            label: Text('좌우 테스트'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange[600],
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // CFR-001: 점진적 증감을 적용한 테스트
  Future<void> _testMovement(BuildContext context, String axis) async {
    final servoService = Provider.of<ServoControlService>(context, listen: false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${axis == 'vertical' ? '상하' : '좌우'} 테스트 중...'),
        duration: Duration(seconds: 3),
      ),
    );

    // 0도 → 90도 → 180도 → 90도 순서로 점진적 테스트
    await servoService.changeAngleGradually(
      currentAngle: 90,
      targetAngle: 0,
      axis: axis,
    );

    await Future.delayed(Duration(seconds: 1));

    await servoService.changeAngleGradually(
      currentAngle: 0,
      targetAngle: 180,
      axis: axis,
    );

    await Future.delayed(Duration(seconds: 1));

    await servoService.changeAngleGradually(
      currentAngle: 180,
      targetAngle: 90,
      axis: axis,
    );
  }

  // BFR-001: 제어 정보 통신으로 저장
  Future<void> _saveSettings(BuildContext context, FanControlProvider provider) async {
    final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);

    try {
      // AFR-001 2: 변경된 경우 값을 '제어 정보 통신'으로 출력
      await bluetoothService.sendControlData(provider.state);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white),
              SizedBox(width: 8),
              Text('설정이 저장되었습니다.'),
            ],
          ),
          backgroundColor: Colors.green[600],
          duration: Duration(seconds: 2),
        ),
      );

      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.error, color: Colors.white),
              SizedBox(width: 8),
              Text('저장 실패: $e'),
            ],
          ),
          backgroundColor: Colors.red[600],
          duration: Duration(seconds: 3),
        ),
      );
    }
  }
}

// 각도 시각화를 위한 커스텀 페인터
class AngleVisualizationPainter extends CustomPainter {
  final int angle;
  final int maxAngle;
  final bool isVertical;
  final Color color;

  AngleVisualizationPainter({
    required this.angle,
    required this.maxAngle,
    required this.isVertical,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.4;

    final paint = Paint()
      ..color = color
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;

    final fillPaint = Paint()
      ..color = color.withOpacity(0.2)
      ..style = PaintingStyle.fill;

    // 배경 원호 (0-180도 범위)
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -3.14159 / 2,
      3.14159,
      false,
      paint..color = color.withOpacity(0.3),
    );

    // 현재 각도 표시
    final angleRad = (angle * 3.14159) / 180;
    final endPoint = Offset(
      center.dx + radius * (isVertical ? 0 : 1) * (angle / 180 - 0.5) * 2,
      center.dy + radius * (isVertical ? 1 : 0) * (angle / 180 - 0.5) * 2,
    );

    canvas.drawLine(center, endPoint, paint..color = color);
    canvas.drawCircle(endPoint, 4, fillPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
