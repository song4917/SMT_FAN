import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import '../main.dart';
import '../services/bluetooth_connection_service.dart';
import '../services/servo_control_service.dart';
import '../services/temperature_service.dart';
import 'angle_setting_screen.dart';
import 'timer_setting_screen.dart';
import 'temperature_monitor_screen.dart';
import 'device_connection_screen.dart';

class MainControlScreen extends StatefulWidget {
  @override
  _MainControlScreenState createState() => _MainControlScreenState();
}

class _MainControlScreenState extends State<MainControlScreen>
    with TickerProviderStateMixin {
  late AnimationController _powerAnimationController;
  late AnimationController _speedAnimationController;
  late Animation<double> _powerAnimation;
  late Animation<double> _speedAnimation;

  @override
  void initState() {
    super.initState();
    _powerAnimationController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _speedAnimationController = AnimationController(
      duration: Duration(milliseconds: 500),
      vsync: this,
    );

    _powerAnimation = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _powerAnimationController, curve: Curves.easeInOut));
    _speedAnimation = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _speedAnimationController, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _powerAnimationController.dispose();
    _speedAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<FanControlProvider>(
      builder: (context, provider, child) {
        final state = provider.state;

        // 애니메이션 상태 업데이트
        if (state.powerOn) {
          _powerAnimationController.forward();
          _speedAnimationController.forward();
        } else {
          _powerAnimationController.reverse();
          _speedAnimationController.reverse();
        }

        return Scaffold(
          backgroundColor: Colors.grey[100],
          appBar: AppBar(
            title: Text('스마트 팬 제어'),
            backgroundColor: Colors.blue[800],
            elevation: 0,
            actions: [
              IconButton(
                icon: Icon(Icons.bluetooth),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => DeviceConnectionScreen()),
                  );
                },
              ),
              Container(
                margin: EdgeInsets.only(right: 16),
                child: Center(
                  child: Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: state.isConnected ? Colors.green : Colors.red,
                    ),
                  ),
                ),
              ),
            ],
          ),
          body: SingleChildScrollView(
            padding: EdgeInsets.all(16),
            child: Column(
              children: [
                // 전원 및 상태 카드 (AFR-001 1-A)
                _buildPowerStatusCard(state, provider),
                SizedBox(height: 16),

                // 팬 속도 제어 카드 (AFR-001 1-B, CFR-002)
                _buildFanSpeedCard(state, provider),
                SizedBox(height: 16),

                // 서보모터 제어 카드 (AFR-001 1-D, 1-E, 1-F, CFR-001)
                _buildServoControlCard(state, provider),
                SizedBox(height: 16),

                // 자동화 및 타이머 카드 (AFR-001 1-C, 1-G)
                _buildAutomationTimerCard(state, provider),
                SizedBox(height: 16),

                // 빠른 액션 버튼들
                _buildQuickActionButtons(context),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPowerStatusCard(state, FanControlProvider provider) {
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: state.powerOn
                ? [Colors.green[400]!, Colors.green[600]!]
                : [Colors.grey[400]!, Colors.grey[600]!],
          ),
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '전원 상태',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      state.powerOn ? '작동 중' : '정지',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                AnimatedBuilder(
                  animation: _powerAnimation,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: 1.0 + (_powerAnimation.value * 0.1),
                      child: GestureDetector(
                        onTap: () async {
                          // AFR-001 1-A: 전원 토글 값 조작
                          provider.updatePower(!state.powerOn);
                          final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);

                          // BFR-001: 제어 정보 통신으로 출력
                          await bluetoothService.sendControlData(provider.state);

                          if (!state.powerOn) {
                            // CFR-001 E: 전원 끄기 시 0도로 복귀
                            final servoService = Provider.of<ServoControlService>(context, listen: false);
                            await servoService.returnToZero();
                          }
                        },
                        child: Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 8,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Icon(
                            state.powerOn ? Icons.power_off : Icons.power,
                            size: 40,
                            color: state.powerOn ? Colors.green[600] : Colors.grey[600],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFanSpeedCard(state, FanControlProvider provider) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.speed, color: Colors.blue[600], size: 24),
                SizedBox(width: 8),
                Text(
                  '팬 속도 제어 (1-100)',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),

            // 속도 게이지
            Container(
              height: 200,
              child: SfRadialGauge(
                axes: <RadialAxis>[
                  RadialAxis(
                    minimum: 1,
                    maximum: 100,
                    ranges: <GaugeRange>[
                      GaugeRange(
                        startValue: 1,
                        endValue: 30,
                        color: Colors.green,
                        startWidth: 10,
                        endWidth: 10,
                      ),
                      GaugeRange(
                        startValue: 30,
                        endValue: 70,
                        color: Colors.orange,
                        startWidth: 10,
                        endWidth: 10,
                      ),
                      GaugeRange(
                        startValue: 70,
                        endValue: 100,
                        color: Colors.red,
                        startWidth: 10,
                        endWidth: 10,
                      ),
                    ],
                    pointers: <GaugePointer>[
                      NeedlePointer(
                        value: state.fanSpeed.toDouble(),
                        enableAnimation: true,
                        animationDuration: 500,
                        animationType: AnimationType.easeInCirc,
                      ),
                    ],
                    annotations: <GaugeAnnotation>[
                      GaugeAnnotation(
                        widget: Container(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '${state.fanSpeed}',
                                style: TextStyle(
                                  fontSize: 32,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[700],
                                ),
                              ),
                              Text(
                                'RPM',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        ),
                        angle: 90,
                        positionFactor: 0.5,
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // 속도 슬라이더 (AFR-001 1-B: 팬 속도 슬라이더 1~100 범위)
            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                activeTrackColor: Colors.blue[600],
                inactiveTrackColor: Colors.blue[100],
                thumbColor: Colors.blue[700],
                overlayColor: Colors.blue[200],
                thumbShape: RoundSliderThumbShape(enabledThumbRadius: 12),
                overlayShape: RoundSliderOverlayShape(overlayRadius: 20),
              ),
              child: Slider(
                value: state.fanSpeed.toDouble(),
                min: 1,
                max: 100,
                divisions: 99,
                label: '${state.fanSpeed}%',
                onChanged: state.powerOn ? (value) {
                  // CFR-002: 팬 속도 조절 값 1~100 정수
                  provider.updateFanSpeed(value.round());
                } : null,
                onChangeEnd: (value) async {
                  if (state.powerOn) {
                    final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);
                    // CFR-002 A: 기존 값에서 새로운 값으로 점진적 변경
                    await bluetoothService.sendCommand('FAN_SPEED_${value.round()}');
                    // BFR-001: 제어 정보 통신으로 출력
                    await bluetoothService.sendControlData(provider.state);
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildServoControlCard(state, FanControlProvider provider) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.settings_input_component, color: Colors.orange[600], size: 24),
                SizedBox(width: 8),
                Text(
                  '서보모터 제어',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),

            // 상하 제어 (CFR-001 A: 상하/좌우의 고정/회전 조작)
            _buildServoControlRow(
              '상하 제어',
              state.verticalFixed,
              state.verticalAngle,
              Icons.swap_vert,
                  (fixed) async {
                // AFR-001 1-D: 고정/회전 토글 값 조작
                provider.updateVerticalFixed(fixed);
                final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);
                final servoService = Provider.of<ServoControlService>(context, listen: false);

                if (fixed) {
                  // CFR-001 B: 고정 상태 제어
                  await servoService.setFixedAngle('vertical', state.verticalAngle);
                } else {
                  // CFR-001 C: 회전 상태 제어
                  await servoService.setRotationRange('vertical', 0, state.maxVerticalAngle);
                }

                // BFR-001: 제어 정보 통신으로 출력
                await bluetoothService.sendControlData(provider.state);
              },
                  (angle) async {
                // AFR-001 1-E, 1-F: 상하/좌우 각도 제어
                provider.updateVerticalAngle(angle);
                final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);
                final servoService = Provider.of<ServoControlService>(context, listen: false);

                if (state.verticalFixed) {
                  // CFR-001: 점진적 증감 적용
                  await servoService.changeAngleGradually(
                    currentAngle: state.verticalAngle,
                    targetAngle: angle,
                    axis: 'vertical',
                  );
                }

                await bluetoothService.sendControlData(provider.state);
              },
            ),

            SizedBox(height: 16),

            // 좌우 제어 (CFR-001 A: 상하/좌우의 고정/회전 조작)
            _buildServoControlRow(
              '좌우 제어',
              state.horizontalFixed,
              state.horizontalAngle,
              Icons.swap_horiz,
                  (fixed) async {
                provider.updateHorizontalFixed(fixed);
                final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);
                final servoService = Provider.of<ServoControlService>(context, listen: false);

                if (fixed) {
                  await servoService.setFixedAngle('horizontal', state.horizontalAngle);
                } else {
                  await servoService.setRotationRange('horizontal', 0, state.maxHorizontalAngle);
                }

                await bluetoothService.sendControlData(provider.state);
              },
                  (angle) async {
                provider.updateHorizontalAngle(angle);
                final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);
                final servoService = Provider.of<ServoControlService>(context, listen: false);

                if (state.horizontalFixed) {
                  await servoService.changeAngleGradually(
                    currentAngle: state.horizontalAngle,
                    targetAngle: angle,
                    axis: 'horizontal',
                  );
                }

                await bluetoothService.sendControlData(provider.state);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildServoControlRow(
      String title,
      bool isFixed,
      int angle,
      IconData icon,
      Function(bool) onFixedChanged,
      Function(int) onAngleChanged,
      ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: Colors.grey[600], size: 20),
            SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.grey[700],
              ),
            ),
            Spacer(),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: isFixed ? Colors.blue[100] : Colors.orange[100],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                isFixed ? '고정' : '회전',
                style: TextStyle(
                  color: isFixed ? Colors.blue[700] : Colors.orange[700],
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 12),

        Row(
          children: [
            Text(
              isFixed ? '각도: ${angle}°' : '회전 범위: 0° - ${angle}°',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            Spacer(),
            Switch(
              value: isFixed,
              onChanged: onFixedChanged,
              activeColor: Colors.blue[600],
            ),
          ],
        ),

        // 각도 슬라이더 (0-180도 범위)
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: Colors.blue[400],
            inactiveTrackColor: Colors.blue[100],
            thumbColor: Colors.blue[600],
            thumbShape: RoundSliderThumbShape(enabledThumbRadius: 8),
          ),
          child: Slider(
            value: angle.toDouble(),
            min: 0,
            max: 180,
            divisions: 36,
            label: '${angle}°',
            onChanged: (value) => onAngleChanged(value.round()),
          ),
        ),
      ],
    );
  }

  Widget _buildAutomationTimerCard(state, FanControlProvider provider) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.auto_awesome, color: Colors.purple[600], size: 24),
                SizedBox(width: 8),
                Text(
                  '자동화 & 타이머',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),

            // 자동화 토글 (AFR-001 1-G: 자동화 토글 값 조작)
            Row(
              children: [
                Icon(Icons.smart_toy, color: Colors.purple[400], size: 20),
                SizedBox(width: 8),
                Text(
                  '자동 온도 추적',
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                Spacer(),
                Switch(
                  value: state.autoMode,
                  onChanged: (value) async {
                    provider.updateAutoMode(value);
                    final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);
                    final servoService = Provider.of<ServoControlService>(context, listen: false);
                    final temperatureService = Provider.of<TemperatureService>(context, listen: false);

                    if (value) {
                      // CFR-001 D: 자동화 상태 및 회전 범위 제어
                      await servoService.startAutomationRotation(
                        maxVerticalAngle: state.maxVerticalAngle,
                        maxHorizontalAngle: state.maxHorizontalAngle,
                      );

                      // CFR-003: 적외선 처리 시작
                      temperatureService.startTemperatureMeasurement(
                        maxVerticalAngle: state.maxVerticalAngle,
                        maxHorizontalAngle: state.maxHorizontalAngle,
                      );
                    } else {
                      servoService.stopRotation();
                      temperatureService.stopTemperatureMeasurement();
                    }

                    // BFR-001: 제어 정보 통신으로 출력
                    await bluetoothService.sendControlData(provider.state);
                  },
                  activeColor: Colors.purple[600],
                ),
              ],
            ),

            SizedBox(height: 16),

            // 타이머 표시 (AFR-001 1-C: 타이머 제어)
            Row(
              children: [
                Icon(Icons.timer, color: Colors.green[400], size: 20),
                SizedBox(width: 8),
                Text(
                  '타이머',
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.green[50],
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.green[200]!),
                  ),
                  child: Text(
                    '${state.timer.inHours.toString().padLeft(2, '0')}:'
                        '${(state.timer.inMinutes % 60).toString().padLeft(2, '0')}:'
                        '${(state.timer.inSeconds % 60).toString().padLeft(2, '0')}',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.green[700],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionButtons(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _buildActionButton(
            '각도 설정',
            Icons.tune,
            Colors.blue,
                () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => AngleSettingScreen()),
            ),
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: _buildActionButton(
            '타이머',
            Icons.timer,
            Colors.green,
                () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => TimerSettingScreen()),
            ),
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: _buildActionButton(
            '온도 모니터',
            Icons.thermostat,
            Colors.red,
                () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => TemperatureMonitorScreen()),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildActionButton(String title, IconData icon, Color color, VoidCallback onPressed) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Column(
            children: [
              Icon(icon, color: color, size: 28),
              SizedBox(height: 8),
              Text(
                title,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey[700],
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
