import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import '../main.dart';
import '../services/bluetooth_connection_service.dart';

class TimerSettingScreen extends StatefulWidget {
  @override
  _TimerSettingScreenState createState() => _TimerSettingScreenState();
}

class _TimerSettingScreenState extends State<TimerSettingScreen>
    with TickerProviderStateMixin {
  late AnimationController _timerAnimationController;
  late AnimationController _buttonAnimationController;
  late Animation<double> _timerAnimation;
  late Animation<double> _buttonAnimation;

  // AFR-001 1-C: 타이머 제어를 위한 변수들
  int _hours = 0;
  int _minutes = 30;
  int _seconds = 0;

  // 실제 타이머 동작을 위한 변수들
  bool _isTimerRunning = false;
  Duration _remainingTime = Duration.zero;
  Timer? _countdownTimer;

  @override
  void initState() {
    super.initState();
    _timerAnimationController = AnimationController(
      duration: Duration(milliseconds: 1000),
      vsync: this,
    );
    _buttonAnimationController = AnimationController(
      duration: Duration(milliseconds: 200),
      vsync: this,
    );

    _timerAnimation = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _timerAnimationController, curve: Curves.easeInOut));
    _buttonAnimation = Tween<double>(begin: 1.0, end: 0.95)
        .animate(CurvedAnimation(parent: _buttonAnimationController, curve: Curves.easeInOut));

    _timerAnimationController.forward();
  }

  @override
  void dispose() {
    _timerAnimationController.dispose();
    _buttonAnimationController.dispose();
    _countdownTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<FanControlProvider>(
      builder: (context, provider, child) {
        final state = provider.state;

        return Scaffold(
          backgroundColor: Colors.grey[50],
          appBar: AppBar(
            title: Text('타이머 설정'),
            backgroundColor: Colors.green[800],
            elevation: 0,
            actions: [
              IconButton(
                icon: Icon(Icons.save),
                onPressed: () => _saveTimer(context, provider),
              ),
            ],
          ),
          body: AnimatedBuilder(
            animation: _timerAnimation,
            builder: (context, child) {
              return Opacity(
                opacity: _timerAnimation.value,
                child: Transform.translate(
                  offset: Offset(0, 50 * (1 - _timerAnimation.value)),
                  child: SingleChildScrollView(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      children: [
                        // 타이머 시각화 카드
                        _buildTimerVisualizationCard(),
                        SizedBox(height: 20),

                        // 시간 설정 카드 (AFR-001 1-C: 증감UI를 사용해 원하는 작동 시간 선택)
                        _buildTimeSettingCard(),
                        SizedBox(height: 20),

                        // 프리셋 타이머 카드
                        _buildPresetTimersCard(),
                        SizedBox(height: 20),

                        // 타이머 제어 버튼들
                        _buildTimerControlButtons(provider),
                        SizedBox(height: 20),

                        // 현재 설정 정보
                        _buildCurrentSettingsCard(state),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildTimerVisualizationCard() {
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        height: 250,
        padding: EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.green[50]!, Colors.green[100]!],
          ),
        ),
        child: Column(
          children: [
            Text(
              '타이머 시각화',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.green[800],
              ),
            ),
            SizedBox(height: 20),

            Expanded(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // 원형 타이머 배경
                  Container(
                    width: 160,
                    height: 160,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.green[200]!, width: 8),
                    ),
                  ),

                  // 진행률 표시
                  SizedBox(
                    width: 160,
                    height: 160,
                    child: CircularProgressIndicator(
                      value: _isTimerRunning ? _getTimerProgress() : 0.0,
                      strokeWidth: 8,
                      backgroundColor: Colors.transparent,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.green[600]!),
                    ),
                  ),

                  // 중앙 시간 표시
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _isTimerRunning ? _formatDuration(_remainingTime) : _formatDuration(_getCurrentDuration()),
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.green[700],
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        _isTimerRunning ? '남은 시간' : '설정 시간',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.green[600],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeSettingCard() {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.access_time, color: Colors.green[600], size: 24),
                SizedBox(width: 8),
                Text(
                  '시간 설정 (증감 UI)',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            SizedBox(height: 24),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // 시간 (AFR-001 1-C: 증감UI를 사용해 원하는 작동 시간 선택)
                _buildTimePicker(
                  label: '시간',
                  value: _hours,
                  maxValue: 23,
                  onChanged: (value) {
                    setState(() {
                      _hours = value;
                    });
                  },
                ),

                Text(
                  ':',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[600],
                  ),
                ),

                // 분
                _buildTimePicker(
                  label: '분',
                  value: _minutes,
                  maxValue: 59,
                  onChanged: (value) {
                    setState(() {
                      _minutes = value;
                    });
                  },
                ),

                Text(
                  ':',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[600],
                  ),
                ),

                // 초
                _buildTimePicker(
                  label: '초',
                  value: _seconds,
                  maxValue: 59,
                  onChanged: (value) {
                    setState(() {
                      _seconds = value;
                    });
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // AFR-001 1-C: 증감UI 구현
  Widget _buildTimePicker({
    required String label,
    required int value,
    required int maxValue,
    required ValueChanged<int> onChanged,
  }) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[600],
            fontWeight: FontWeight.w500,
          ),
        ),
        SizedBox(height: 8),

        Container(
          width: 80,
          height: 120,
          decoration: BoxDecoration(
            color: Colors.green[50],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.green[200]!),
          ),
          child: Column(
            children: [
              // 증가 버튼 (증감UI)
              Expanded(
                child: InkWell(
                  onTap: () {
                    if (value < maxValue) onChanged(value + 1);
                  },
                  borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                  child: Container(
                    width: double.infinity,
                    child: Icon(
                      Icons.keyboard_arrow_up,
                      color: Colors.green[600],
                      size: 24,
                    ),
                  ),
                ),
              ),

              // 값 표시
              Container(
                height: 40,
                child: Center(
                  child: Text(
                    value.toString().padLeft(2, '0'),
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.green[700],
                    ),
                  ),
                ),
              ),

              // 감소 버튼 (증감UI)
              Expanded(
                child: InkWell(
                  onTap: () {
                    if (value > 0) onChanged(value - 1);
                  },
                  borderRadius: BorderRadius.vertical(bottom: Radius.circular(12)),
                  child: Container(
                    width: double.infinity,
                    child: Icon(
                      Icons.keyboard_arrow_down,
                      color: Colors.green[600],
                      size: 24,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPresetTimersCard() {
    final presets = [
      {'name': '5분', 'h': 0, 'm': 5, 's': 0},
      {'name': '10분', 'h': 0, 'm': 10, 's': 0},
      {'name': '30분', 'h': 0, 'm': 30, 's': 0},
      {'name': '1시간', 'h': 1, 'm': 0, 's': 0},
      {'name': '2시간', 'h': 2, 'm': 0, 's': 0},
      {'name': '3시간', 'h': 3, 'm': 0, 's': 0},
    ];

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '빠른 설정',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            SizedBox(height: 16),

            GridView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                childAspectRatio: 2.5,
              ),
              itemCount: presets.length,
              itemBuilder: (context, index) {
                final preset = presets[index];
                return ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _hours = preset['h'] as int;
                      _minutes = preset['m'] as int;
                      _seconds = preset['s'] as int;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green[50],
                    foregroundColor: Colors.green[700],
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    preset['name'] as String,
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimerControlButtons(FanControlProvider provider) {
    return Row(
      children: [
        Expanded(
          child: AnimatedBuilder(
            animation: _buttonAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _buttonAnimation.value,
                child: ElevatedButton.icon(
                  onPressed: _isTimerRunning ? _stopTimer : _startTimer,
                  icon: Icon(_isTimerRunning ? Icons.stop : Icons.play_arrow),
                  label: Text(_isTimerRunning ? '정지' : '시작'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isTimerRunning ? Colors.red[600] : Colors.green[600],
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: _resetTimer,
            icon: Icon(Icons.refresh),
            label: Text('리셋'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.grey[600],
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCurrentSettingsCard(state) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '현재 설정',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            SizedBox(height: 16),

            Row(
              children: [
                Icon(Icons.power_settings_new, color: Colors.blue[600], size: 20),
                SizedBox(width: 8),
                Text('전원: ${state.powerOn ? "켜짐" : "꺼짐"}'),
                Spacer(),
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: state.powerOn ? Colors.green : Colors.red,
                  ),
                ),
              ],
            ),

            SizedBox(height: 12),

            Row(
              children: [
                Icon(Icons.speed, color: Colors.orange[600], size: 20),
                SizedBox(width: 8),
                Text('팬 속도: ${state.fanSpeed}%'),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.orange[100],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '${state.fanSpeed}%',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.orange[700],
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: 12),

            Row(
              children: [
                Icon(Icons.auto_awesome, color: Colors.purple[600], size: 20),
                SizedBox(width: 8),
                Text('자동화: ${state.autoMode ? "활성화" : "비활성화"}'),
                Spacer(),
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: state.autoMode ? Colors.purple : Colors.grey,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Duration _getCurrentDuration() {
    return Duration(hours: _hours, minutes: _minutes, seconds: _seconds);
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds";
  }

  double _getTimerProgress() {
    if (_remainingTime.inSeconds == 0) return 0.0;
    Duration totalDuration = _getCurrentDuration();
    return 1.0 - (_remainingTime.inSeconds / totalDuration.inSeconds);
  }

  // 검색 결과의 Timer.periodic 방식을 적용한 실제 타이머 구현
  void _startTimer() {
    setState(() {
      _isTimerRunning = true;
      _remainingTime = _getCurrentDuration();
    });

    _buttonAnimationController.forward().then((_) {
      _buttonAnimationController.reverse();
    });

    // Timer.periodic을 사용한 실제 카운트다운 구현
    _countdownTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_remainingTime.inSeconds > 0) {
        setState(() {
          _remainingTime = Duration(seconds: _remainingTime.inSeconds - 1);
        });
      } else {
        // 타이머 완료
        timer.cancel();
        setState(() {
          _isTimerRunning = false;
        });

        // 타이머 완료 시 팬 자동 정지 (유스케이스 연동)
        _onTimerCompleted();
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('타이머가 시작되었습니다: ${_formatDuration(_getCurrentDuration())}'),
        backgroundColor: Colors.green[600],
      ),
    );
  }

  void _stopTimer() {
    _countdownTimer?.cancel();
    setState(() {
      _isTimerRunning = false;
    });

    _buttonAnimationController.forward().then((_) {
      _buttonAnimationController.reverse();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('타이머가 정지되었습니다.'),
        backgroundColor: Colors.red[600],
      ),
    );
  }

  void _resetTimer() {
    _countdownTimer?.cancel();
    setState(() {
      _isTimerRunning = false;
      _remainingTime = Duration.zero;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('타이머가 리셋되었습니다.'),
        backgroundColor: Colors.grey[600],
      ),
    );
  }

  // 타이머 완료 시 처리 (유스케이스 연동)
  void _onTimerCompleted() async {
    final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);

    // 타이머 완료 시 팬 전원 자동 OFF
    await bluetoothService.sendCommand('TIMER_COMPLETED_POWER_OFF');

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('⏰ 타이머 완료! 팬이 자동으로 정지되었습니다.'),
        backgroundColor: Colors.orange[600],
        duration: Duration(seconds: 3),
      ),
    );
  }

  // AFR-001 2: 변경된 경우 값을 '제어 정보 통신'으로 출력
  Future<void> _saveTimer(BuildContext context, FanControlProvider provider) async {
    final duration = _getCurrentDuration();
    provider.updateTimer(duration);

    final bluetoothService = Provider.of<BluetoothConnectionService>(context, listen: false);

    try {
      // BFR-001: 제어 정보 통신으로 타이머 설정 전송
      await bluetoothService.sendControlData(provider.state);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.white),
              SizedBox(width: 8),
              Text('타이머가 저장되었습니다: ${_formatDuration(duration)}'),
            ],
          ),
          backgroundColor: Colors.green[600],
          duration: Duration(seconds: 2),
        ),
      );

      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.error, color: Colors.white),
              SizedBox(width: 8),
              Text('저장 실패: $e'),
            ],
          ),
          backgroundColor: Colors.red[600],
          duration: Duration(seconds: 3),
        ),
      );
    }
  }
}
