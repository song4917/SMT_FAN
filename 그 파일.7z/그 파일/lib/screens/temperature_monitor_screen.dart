import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import '../services/temperature_service.dart';
import '../models/temperature_data.dart';

class TemperatureMonitorScreen extends StatefulWidget {
  @override
  _TemperatureMonitorScreenState createState() => _TemperatureMonitorScreenState();
}

class _TemperatureMonitorScreenState extends State<TemperatureMonitorScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  TemperatureData? _currentTemperatureData;
  bool _isMonitoring = false;
  double _currentTemp = 25.0;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _animationController, curve: Curves.easeIn));

    _animationController.forward();
    _initializeTemperatureData();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _initializeTemperatureData() {
    // CFR-003: 2차원 배열 초기화 (3도마다 측정)
    _currentTemperatureData = TemperatureData(
      temperatureMap: List.generate(
        60, // 180도 / 3도 간격
            (i) => List.generate(60, (j) => 25.0 + (i + j) * 0.1),
      ),
      threshold: 30.0, // 특정 온도 기준값
    );

    // 시뮬레이션된 고온 지점 추가
    _currentTemperatureData!.updateTemperature(15, 20, 35.2);
    _currentTemperatureData!.updateTemperature(35, 10, 33.8);
    _currentTemperatureData!.updateTemperature(25, 40, 36.1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text('온도 모니터링'),
        backgroundColor: Colors.red[800],
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(_isMonitoring ? Icons.pause : Icons.play_arrow),
            onPressed: _toggleMonitoring,
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: _fadeAnimation,
        builder: (context, child) {
          return Opacity(
            opacity: _fadeAnimation.value,
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  // 실시간 온도 게이지 (검색 결과의 Syncfusion Radial Gauge 활용)
                  _buildTemperatureGaugeCard(),
                  SizedBox(height: 16),

                  // 온도 히트맵 카드 (CFR-003: 2차원 배열 시각화)
                  _buildHeatmapCard(),
                  SizedBox(height: 16),

                  // 실시간 통계 카드
                  _buildStatisticsCard(),
                  SizedBox(height: 16),

                  // 고온 지점 목록 카드 (CFR-003: 특정 온도보다 높은 포인트)
                  _buildHotSpotsCard(),
                  SizedBox(height: 16),

                  // 온도 변화 그래프 카드
                  _buildTemperatureGraphCard(),
                  SizedBox(height: 16),

                  // 제어 설정 카드
                  _buildControlSettingsCard(),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // 검색 결과의 Syncfusion Radial Gauge를 활용한 온도 게이지
  Widget _buildTemperatureGaugeCard() {
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        height: 300,
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.red[50]!, Colors.red[100]!],
          ),
        ),
        child: Column(
          children: [
            Text(
              '실시간 온도 모니터',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.red[800],
              ),
            ),
            SizedBox(height: 20),

            Expanded(
              child: SfRadialGauge(
                axes: <RadialAxis>[
                  RadialAxis(
                    minimum: 0,
                    maximum: 50,
                    ranges: <GaugeRange>[
                      GaugeRange(
                        startValue: 0,
                        endValue: 20,
                        color: Colors.blue,
                        startWidth: 10,
                        endWidth: 10,
                      ),
                      GaugeRange(
                        startValue: 20,
                        endValue: 30,
                        color: Colors.green,
                        startWidth: 10,
                        endWidth: 10,
                      ),
                      GaugeRange(
                        startValue: 30,
                        endValue: 40,
                        color: Colors.orange,
                        startWidth: 10,
                        endWidth: 10,
                      ),
                      GaugeRange(
                        startValue: 40,
                        endValue: 50,
                        color: Colors.red,
                        startWidth: 10,
                        endWidth: 10,
                      ),
                    ],
                    pointers: <GaugePointer>[
                      NeedlePointer(
                        value: _currentTemp,
                        enableAnimation: true,
                        animationDuration: 1000,
                        animationType: AnimationType.easeInCirc,
                      ),
                    ],
                    annotations: <GaugeAnnotation>[
                      GaugeAnnotation(
                        widget: Container(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '${_currentTemp.toStringAsFixed(1)}',
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.red[700],
                                ),
                              ),
                              Text(
                                '°C',
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        ),
                        angle: 90,
                        positionFactor: 0.5,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeatmapCard() {
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.red[50]!, Colors.red[100]!],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.thermostat, color: Colors.red[600], size: 24),
                SizedBox(width: 8),
                Text(
                  '온도 히트맵 (3도 간격 측정)',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.red[800],
                  ),
                ),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _isMonitoring ? Colors.green[100] : Colors.grey[200],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _isMonitoring ? Colors.green : Colors.grey,
                        ),
                      ),
                      SizedBox(width: 4),
                      Text(
                        _isMonitoring ? '측정 중' : '정지',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: _isMonitoring ? Colors.green[700] : Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),

            // CFR-003: 2차원 배열 시각화 (히트맵)
            Container(
              height: 300,
              child: _currentTemperatureData != null
                  ? CustomPaint(
                painter: HeatmapPainter(
                  temperatureData: _currentTemperatureData!,
                  cellSize: 4.0, // 작은 셀 크기로 세밀한 표현
                ),
                child: Container(),
              )
                  : Center(child: CircularProgressIndicator()),
            ),

            SizedBox(height: 16),

            // 온도 범례
            _buildTemperatureLegend(),
          ],
        ),
      ),
    );
  }

  Widget _buildTemperatureLegend() {
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      children: [
        _buildLegendItem(Colors.blue[300]!, '낮음 (<25°C)'),
        _buildLegendItem(Colors.green[300]!, '보통 (25-30°C)'),
        _buildLegendItem(Colors.orange[300]!, '높음 (30-35°C)'),
        _buildLegendItem(Colors.red[400]!, '매우 높음 (>35°C)'),
      ],
    );
  }

  Widget _buildLegendItem(Color color, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        SizedBox(width: 4),
        Text(
          label,
          style: TextStyle(fontSize: 10, color: Colors.grey[600]),
        ),
      ],
    );
  }

  Widget _buildStatisticsCard() {
    if (_currentTemperatureData == null) return Container();

    final temperatures = _currentTemperatureData!.temperatureMap
        .expand((row) => row)
        .toList();
    final avgTemp = temperatures.reduce((a, b) => a + b) / temperatures.length;
    final maxTemp = temperatures.reduce((a, b) => a > b ? a : b);
    final minTemp = temperatures.reduce((a, b) => a < b ? a : b);

    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '실시간 통계',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            SizedBox(height: 16),

            Row(
              children: [
                Expanded(
                  child: _buildStatItem(
                    '평균 온도',
                    '${avgTemp.toStringAsFixed(1)}°C',
                    Icons.thermostat_outlined,
                    Colors.blue[600]!,
                  ),
                ),
                Expanded(
                  child: _buildStatItem(
                    '최고 온도',
                    '${maxTemp.toStringAsFixed(1)}°C',
                    Icons.keyboard_arrow_up,
                    Colors.red[600]!,
                  ),
                ),
                Expanded(
                  child: _buildStatItem(
                    '최저 온도',
                    '${minTemp.toStringAsFixed(1)}°C',
                    Icons.keyboard_arrow_down,
                    Colors.green[600]!,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 24),
        SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  // CFR-003: 특정 온도보다 높은 포인트 확인
  Widget _buildHotSpotsCard() {
    if (_currentTemperatureData == null) return Container();

    final hotSpots = _currentTemperatureData!.hotSpots;

    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.warning, color: Colors.orange[600], size: 20),
                SizedBox(width: 8),
                Text(
                  '고온 지점 (${_currentTemperatureData!.threshold}°C 이상)',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),

            if (hotSpots.isEmpty)
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.green[50],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.check_circle, color: Colors.green[600]),
                    SizedBox(width: 8),
                    Text(
                      '고온 지점이 감지되지 않았습니다.',
                      style: TextStyle(color: Colors.green[700]),
                    ),
                  ],
                ),
              )
            else
              ...hotSpots.asMap().entries.map((entry) {
                final index = entry.key;
                final spot = entry.value;
                final temp = _currentTemperatureData!.temperatureMap[spot.x][spot.y];
                final angleX = spot.x * 3; // 3도 간격으로 실제 각도 변환
                final angleY = spot.y * 3;

                return Container(
                  margin: EdgeInsets.only(bottom: 8),
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.red[50],
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.red[200]!),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color: Colors.red[600],
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text(
                            '${index + 1}',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '각도: 상하 ${angleX}°, 좌우 ${angleY}°',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Text(
                              '온도: ${temp.toStringAsFixed(1)}°C',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (_currentTemperatureData!.currentTarget == spot)
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.blue[100],
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '현재 타겟',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue[700],
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              }).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildTemperatureGraphCard() {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '온도 변화 그래프',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            SizedBox(height: 20),

            Container(
              height: 200,
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(show: true),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 40,
                        getTitlesWidget: (value, meta) {
                          return Text(
                            '${value.toInt()}°C',
                            style: TextStyle(fontSize: 10),
                          );
                        },
                      ),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          return Text(
                            '${value.toInt()}분',
                            style: TextStyle(fontSize: 10),
                          );
                        },
                      ),
                    ),
                    rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  borderData: FlBorderData(show: true),
                  lineBarsData: [
                    LineChartBarData(
                      spots: _generateTemperatureSpots(),
                      isCurved: true,
                      color: Colors.red[400],
                      barWidth: 3,
                      dotData: FlDotData(show: false),
                      belowBarData: BarAreaData(
                        show: true,
                        color: Colors.red[100]!.withOpacity(0.3),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<FlSpot> _generateTemperatureSpots() {
    // 시뮬레이션된 온도 변화 데이터 생성
    return List.generate(20, (index) {
      return FlSpot(
        index.toDouble(),
        25 + (index * 0.5) + (index % 3) * 2,
      );
    });
  }

  Widget _buildControlSettingsCard() {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '모니터링 설정',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            SizedBox(height: 16),

            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _toggleMonitoring,
                    icon: Icon(_isMonitoring ? Icons.pause : Icons.play_arrow),
                    label: Text(_isMonitoring ? '모니터링 정지' : '모니터링 시작'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isMonitoring ? Colors.orange[600] : Colors.green[600],
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _resetData,
                    icon: Icon(Icons.refresh),
                    label: Text('데이터 리셋'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[600],
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // CFR-003: 적외선 처리 시작/정지
  void _toggleMonitoring() {
    setState(() {
      _isMonitoring = !_isMonitoring;
    });

    final temperatureService = Provider.of<TemperatureService>(context, listen: false);

    if (_isMonitoring) {
      // CFR-003: 각도(3도)마다 적외선 온도 센서를 통해 온도 측정
      temperatureService.startTemperatureMeasurement(
        maxVerticalAngle: 180,
        maxHorizontalAngle: 180,
        measurementInterval: 3, // 3도 간격
      );

      // 온도 데이터 스트림 구독
      temperatureService.temperatureStream.listen((data) {
        setState(() {
          _currentTemperatureData = data;
          // 현재 온도 업데이트 (시뮬레이션)
          _currentTemp = 25.0 + (DateTime.now().millisecondsSinceEpoch % 1000) / 100;
        });
      });
    } else {
      temperatureService.stopTemperatureMeasurement();
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isMonitoring ? '온도 모니터링을 시작했습니다.' : '온도 모니터링을 정지했습니다.'),
        backgroundColor: _isMonitoring ? Colors.green[600] : Colors.orange[600],
      ),
    );
  }

  void _resetData() {
    setState(() {
      _initializeTemperatureData();
      _currentTemp = 25.0;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('온도 데이터가 리셋되었습니다.'),
        backgroundColor: Colors.blue[600],
      ),
    );
  }
}

// CFR-003: 2차원 배열 히트맵 시각화를 위한 커스텀 페인터
class HeatmapPainter extends CustomPainter {
  final TemperatureData temperatureData;
  final double cellSize;

  HeatmapPainter({
    required this.temperatureData,
    required this.cellSize,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();

    for (int i = 0; i < temperatureData.temperatureMap.length; i++) {
      for (int j = 0; j < temperatureData.temperatureMap[i].length; j++) {
        final temperature = temperatureData.temperatureMap[i][j];

        // 온도에 따른 색상 결정 (검색 결과의 온도 범위 적용)
        Color color;
        if (temperature < 25) {
          color = Colors.blue[300]!;
        } else if (temperature < 30) {
          color = Colors.green[300]!;
        } else if (temperature < 35) {
          color = Colors.orange[300]!;
        } else {
          color = Colors.red[400]!;
        }

        paint.color = color;

        final rect = Rect.fromLTWH(
          j * cellSize,
          i * cellSize,
          cellSize,
          cellSize,
        );

        canvas.drawRect(rect, paint);

        // CFR-003: 현재 타겟 지점 표시
        if (temperatureData.currentTarget != null &&
            temperatureData.currentTarget!.x == i &&
            temperatureData.currentTarget!.y == j) {
          paint.color = Colors.blue[800]!;
          paint.style = PaintingStyle.stroke;
          paint.strokeWidth = 2;
          canvas.drawRect(rect, paint);
          paint.style = PaintingStyle.fill;
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
